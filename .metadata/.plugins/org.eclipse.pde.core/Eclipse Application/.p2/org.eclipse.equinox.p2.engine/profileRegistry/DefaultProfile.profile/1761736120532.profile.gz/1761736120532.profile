<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1761736120532'>
  <properties size='11'>
    <property name='org.eclipse.equinox.p2.cache' value='D:\Aurionpro Office\Dipesh_Task_1\.metadata\.plugins\org.eclipse.pde.core'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='D:\Softwares\sts-4.23.1.RELEASE'/>
    <property name='eclipse.touchpoint.launcherName' value='SpringToolSuite4'/>
    <property name='org.eclipse.equinox.p2.cache.extensions' value='file:/D:/Softwares/sts-4.23.1.RELEASE/.eclipseextension|file:/D:/Softwares/sts-4.23.1.RELEASE/configuration/org.eclipse.osgi/228/data/listener_1925729951/'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='D:\Softwares\sts-4.23.1.RELEASE'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='D:\Aurionpro Office\Dipesh_Task_1\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='D:\Aurionpro Office\Dipesh_Task_1\.metadata\.plugins\org.eclipse.pde.core\Eclipse Application\eclipse.ini.ignored'/>
  </properties>
  <units size='40'>
    <unit id='SharedProfile_DefaultProfile' version='1.0.0.1761728855841' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_DefaultProfile' version='1.0.0.1761728855841'/>
      </provides>
      <requires size='753'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.jar&apos;, version(&apos;2.37.0.v20240203-0859&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.imports&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.jar&apos;, version(&apos;1.3.400.v20240417-0757&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.core&apos;, version(&apos;4.10.300.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.win32.x86_64&apos;, version(&apos;11.6.0.202406041555&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.archive&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.genericeditor.extension&apos;, version(&apos;1.2.400.v20240430-0753&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-vintage-engine&apos;, version(&apos;5.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.7.100.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.user&apos;, version(&apos;4.32.0.v20240529-0958&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-api&apos;, version(&apos;1.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp&apos;, version(&apos;3.11.400.v20240508-1954&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.bcoview.feature.feature.group&apos;, version(&apos;1.2.400.v20240322-0935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore.ui&apos;, version(&apos;1.1.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.10.0.v20230422-0242&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_userdoc.feature.feature.group&apos;, version(&apos;3.3.300.v201901310132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jboss.tools.m2e.wro4j.ui&apos;, version(&apos;1.2.1.202301111328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.core&apos;, version(&apos;2.6.1.20240602-2342&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.16.400.v20240418-1547&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.core&apos;, version(&apos;1.3.400.v20240321-1452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.quicksearch&apos;, version(&apos;1.2.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.xml.namespaces.feature.feature.group&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.xml.bind&apos;, version(&apos;2.3.3.v20221203-1659&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.control.feature.feature.group&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.branding.sts4&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.resolve&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.monitoring&apos;, version(&apos;1.3.300.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare&apos;, version(&apos;3.11.0.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.springframework.boot.ide.branding.sts4.executable.win32.win32.x86_64&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr&apos;, version(&apos;2.2.10&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype.annotations&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.promise&apos;, version(&apos;1.3.0.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.update.configurator&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_adapters.feature.feature.jar&apos;, version(&apos;3.34.0.v202405181536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources&apos;, version(&apos;3.20.200.v20240513-1323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.profiles.ui&apos;, version(&apos;2.0.302.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.feature.jar&apos;, version(&apos;1.2.0.v20210517-0327&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry&apos;, version(&apos;1.4.100.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.annotation-api&apos;, version(&apos;2.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.build&apos;, version(&apos;3.12.400.v20240515-2132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.7.100.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.6.100.v20240519-2013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.cli&apos;, version(&apos;1.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.springframework.boot.ide.branding.sts4.config.win32.win32.x86_64&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.ui&apos;, version(&apos;1.3.400.v20240416-0657&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.asciidoc.ui&apos;, version(&apos;4.3.0.v20240601-0538&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_ui.feature.feature.jar&apos;, version(&apos;3.3.1900.v202405150145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.descriptor&apos;, version(&apos;3.2.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.versioncontrol.ignores.plugin.git&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.collections&apos;, version(&apos;3.2.2.v201511171945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.plus&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.core&apos;, version(&apos;1.3.400.v20240321-1452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.maven-artifact-transfer&apos;, version(&apos;0.13.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.local&apos;, version(&apos;4.8.100.202402230238&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.wtp.feature.feature.jar&apos;, version(&apos;1.6.1.20231024-1618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.fasterxml.jackson.core.jackson-core&apos;, version(&apos;2.17.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.ssh&apos;, version(&apos;4.8.300.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.project.facet.ui&apos;, version(&apos;1.5.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.4.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5&apos;, version(&apos;5.2.3.v20230922-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.3.300.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.lemminx.feature.feature.jar&apos;, version(&apos;2.0.600.20240219-1707&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.win32.x86_64&apos;, version(&apos;21.0.3.v20240426-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.36.0.v20240203-0859&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.feature.group&apos;, version(&apos;3.1.9.v20240115-1636&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.14.100.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.cm&apos;, version(&apos;1.6.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.interceptor-api&apos;, version(&apos;1.2.5&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core&apos;, version(&apos;3.10.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.branding&apos;, version(&apos;3.1.9.v20240115-1636&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.ui.doc.user&apos;, version(&apos;1.1.600.v201901310132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.inject.jakarta.inject-api&apos;, version(&apos;1.0.5&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.inject.jakarta.inject-api&apos;, version(&apos;2.0.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.12.100.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;1.1.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emfworkbench.integration&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.31.100.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.session&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets&apos;, version(&apos;3.8.400.v20240414-1916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-runner&apos;, version(&apos;1.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.core&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest&apos;, version(&apos;2.2.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.junit&apos;, version(&apos;4.13.2.v20230809-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.scm&apos;, version(&apos;2.0.202.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch&apos;, version(&apos;0.1.55.v20230916-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.compiler.batch&apos;, version(&apos;3.38.0.v20240524-2033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.feature.jar&apos;, version(&apos;1.10.3.v20240228-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.pluggable.core&apos;, version(&apos;1.4.400.v20240321-1252&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.20.0.v20240509-1421&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit5.runtime&apos;, version(&apos;1.1.300.v20231214-1952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_core.feature.feature.group&apos;, version(&apos;3.4.0.v202311141839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.validation&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jaxen&apos;, version(&apos;2.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.15.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.15.300.v20240418-0734&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.process&apos;, version(&apos;4.9.100.202402230238&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.restart&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.14.400.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sonatype.m2e.egit.feature.feature.group&apos;, version(&apos;0.17.0.202209271423&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.win32&apos;, version(&apos;1.1.400.v20240414-0911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.jndi&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analysis-smartcn&apos;, version(&apos;9.10.0.v20240221-0830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.ui&apos;, version(&apos;1.6.200.v202308172116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna&apos;, version(&apos;5.14.0.v20231211-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.jffi.native&apos;, version(&apos;1.3.13.v20240215-1616&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.doc.user&apos;, version(&apos;3.15.2200.v20240529-0958&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5-win&apos;, version(&apos;5.2.1.v20230802-0847&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.feature.feature.group&apos;, version(&apos;1.3.400.v20240417-0757&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage&apos;, version(&apos;1.2.0.v20210517-0327&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.feature.group&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.5.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit&apos;, version(&apos;2.21.0.v20231208-1346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.ui&apos;, version(&apos;4.11.500.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.workspace.cli&apos;, version(&apos;0.3.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.lfs.feature.group&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jee.ejb&apos;, version(&apos;1.1.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.ui&apos;, version(&apos;3.1.9.v20240115-1636&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.bnd.util&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro&apos;, version(&apos;3.7.400.v20240414-0828&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.project.facet.ui&apos;, version(&apos;1.5.0.v202405122301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base&apos;, version(&apos;4.4.400.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications&apos;, version(&apos;0.7.200.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.hk2.utils&apos;, version(&apos;3.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;1.2.100.v20240212-1051&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.annotation&apos;, version(&apos;2.3.0.v20240111-2306&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.xml.feature.feature.jar&apos;, version(&apos;1.3.4.202405270639&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.jdt.docker.launcher&apos;, version(&apos;1.0.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.group&apos;, version(&apos;1.4.2400.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.versioncontrol.ignores.manager&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler&apos;, version(&apos;1.6.300.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.3.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.feature.feature.jar&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.branding.sts4.executable.win32.win32.x86_64.SpringToolSuite4&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.ext.feature.feature.group&apos;, version(&apos;3.4.1000.v202405180431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.jar&apos;, version(&apos;3.14.1900.v20230715-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.jar&apos;, version(&apos;1.6.2.v20231021-2127&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.feature.group&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.xml.bind-api&apos;, version(&apos;4.0.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.frameworks&apos;, version(&apos;1.2.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.8.400.v20240511-1722&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tips.feature.feature.jar&apos;, version(&apos;0.4.400.v20240525-0701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpkix&apos;, version(&apos;1.78.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jsoup&apos;, version(&apos;1.17.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.10.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.jar&apos;, version(&apos;1.7.200.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki.ui&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.11.100.v20240327-0645&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.logback.feature.feature.group&apos;, version(&apos;2.6.1.20240411-1743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.tooling.boot.ls&apos;, version(&apos;1.55.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.group&apos;, version(&apos;3.19.500.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.feature.group&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.ssh.feature.feature.group&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.xml.core&apos;, version(&apos;1.2.900.v202405130132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.jar&apos;, version(&apos;2.3.1800.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.apache-jsp&apos;, version(&apos;9.0.83&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui&apos;, version(&apos;4.7.0.v20240414-1916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui.templates&apos;, version(&apos;3.8.400.v20240321-1452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.project.facet.core&apos;, version(&apos;1.5.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.chabicht.code_intelligence.feature.feature.jar&apos;, version(&apos;1.0.0.202506262339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search.core&apos;, version(&apos;3.16.200.v20240502-1134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.annotations.controller&apos;, version(&apos;1.2.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser&apos;, version(&apos;3.8.300.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jee&apos;, version(&apos;1.1.100.v202405180437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.enterprise.cdi-api&apos;, version(&apos;2.0.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.maven.runtime&apos;, version(&apos;3.9.700.20240602-2313&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apiguardian.api&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.branding.feature.feature.jar&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springsource.ide.eclipse.commons.livexp&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;1.5.400.v20240416-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.workbench&apos;, version(&apos;2.2.0.v202405180437&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sonatype.m2e.egit.feature.feature.jar&apos;, version(&apos;0.17.0.202209271423&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.a64asm&apos;, version(&apos;1.0.0.v20230715-0746&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.ejb&apos;, version(&apos;1.2.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.9.400.v20240414-1643&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.el.javax.el&apos;, version(&apos;3.0.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core&apos;, version(&apos;1.5.400.v20240413-1649&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.jersey.connectors.jersey-apache-connector&apos;, version(&apos;3.1.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.gitflow&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.sourcelookup.ui&apos;, version(&apos;2.0.401.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.lang3&apos;, version(&apos;3.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui&apos;, version(&apos;1.5.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools&apos;, version(&apos;1.3.400.v20240419-1823&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.common&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.4.800.v20240513-1104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.buildship30&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources.win32.x86_64&apos;, version(&apos;3.5.500.v20220812-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite&apos;, version(&apos;1.3.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.security&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.service&apos;, version(&apos;1.0.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.servlet&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.formatterapp&apos;, version(&apos;1.2.250.v20240311-0615&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.group&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.ui.infopop&apos;, version(&apos;1.1.200.v201901310132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.launch&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.plus&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bndtools.jareditor&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-launcher&apos;, version(&apos;1.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.enterprise.lang-model&apos;, version(&apos;4.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.17.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug&apos;, version(&apos;3.21.400.v20240418-1414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.16.0.v20231208-1346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.runtime&apos;, version(&apos;3.8.400.v20240321-1452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.12.300.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.wtp.feature.feature.group&apos;, version(&apos;1.6.1.20231024-1618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.jsonrpc&apos;, version(&apos;0.23.1.v20240521-1815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5.win32&apos;, version(&apos;1.1.0.v20230423-0417&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.core&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.jar&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.jar&apos;, version(&apos;2.4.2400.v20240519-2013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.activation-api&apos;, version(&apos;2.1.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;2.4.300.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.feature.group&apos;, version(&apos;21.0.3.v20240426-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.emf&apos;, version(&apos;1.2.700.v202007161535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log&apos;, version(&apos;1.4.400.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.joni&apos;, version(&apos;2.2.1.v20230703-0749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.jersey.core.jersey-server&apos;, version(&apos;3.1.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.http.core&apos;, version(&apos;1.0.400.v202007170127&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.lfs&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.prefs&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.branding.sts4.executable.win32.win32.x86_64&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.profiles.core&apos;, version(&apos;2.1.202.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.132.0.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tips.ide&apos;, version(&apos;0.3.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.ui.css&apos;, version(&apos;1.10.3.v20240221-1216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;1.5.100.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.yaml.snakeyaml&apos;, version(&apos;2.2.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full.feature.jar&apos;, version(&apos;21.0.3.v20240426-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.annotations&apos;, version(&apos;1.3.300.v20240503-2142&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.9.100.v20240511-1722&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.jar&apos;, version(&apos;4.32.0.v20240528-0813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.analysis&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.embedder.node.win32.x86_64&apos;, version(&apos;1.1.1.202405211302&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sonatype.m2e.egit&apos;, version(&apos;0.17.0.202209271423&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.core&apos;, version(&apos;3.8.400.v20240326-0804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.jsonrpc.debug&apos;, version(&apos;0.23.1.v20240521-1815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.local.feature.feature.jar&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit4.runtime&apos;, version(&apos;1.3.100.v20231214-1952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem.win32.x86_64&apos;, version(&apos;1.4.300.v20220812-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.apt.ui&apos;, version(&apos;3.8.400.v20240321-1252&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.help.ui&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpcore&apos;, version(&apos;4.4.16.v20221207-1049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.reactivestreams.reactive-streams&apos;, version(&apos;1.0.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.3.0.v20230422-0242&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.aries.spifly.dynamic.bundle&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.discovery&apos;, version(&apos;1.3.300.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-engine&apos;, version(&apos;5.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.common&apos;, version(&apos;3.2.104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.206.0.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.4.300.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide&apos;, version(&apos;3.17.200.v20231201-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.ssl&apos;, version(&apos;1.1.0.v20230422-0242&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.ext.feature.feature.jar&apos;, version(&apos;3.4.1000.v202405180431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.wireadmin&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.edit&apos;, version(&apos;2.14.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.gson&apos;, version(&apos;2.11.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.fproj.feature.jar&apos;, version(&apos;3.7.4.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.editor.ls&apos;, version(&apos;1.0.1.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.fasterxml.jackson.core.jackson-annotations&apos;, version(&apos;2.17.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.fasterxml.jackson.core.jackson-databind&apos;, version(&apos;2.17.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.group&apos;, version(&apos;1.4.2400.v20240519-2013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.swt.win32&apos;, version(&apos;1.2.300.v20240416-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.dash.feature.feature.jar&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.tooling.boot.ls.feature.feature.group&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.opentest4j&apos;, version(&apos;1.3.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.felix.scr&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava.failureaccess&apos;, version(&apos;1.0.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.chabicht.code-intelligence&apos;, version(&apos;1.0.0.202506262339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.3.200.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.editor.support&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.xml.feature.feature.group&apos;, version(&apos;1.3.4.202405270639&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.embedder.node.feature.feature.group&apos;, version(&apos;1.1.2.202405271237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.win32&apos;, version(&apos;1.3.0.v20240419-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state&apos;, version(&apos;1.2.1000.v20240213-1057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.jar&apos;, version(&apos;1.1.501.v20230507-1921&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tips.core&apos;, version(&apos;0.3.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.tooling.gradle&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.ssh.feature.feature.jar&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.3.300.v20240207-1113&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.jee.web&apos;, version(&apos;1.1.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.full&apos;, version(&apos;21.0.3.v20240426-1530&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.frameworks&apos;, version(&apos;1.3.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.headless.build.plugin.gradle&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki.ui&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.feature.jar&apos;, version(&apos;3.19.500.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery.compatibility&apos;, version(&apos;1.3.300.v20240417-0757&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.feature.feature.jar&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.3.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core&apos;, version(&apos;3.38.0.v20240528-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.preview&apos;, version(&apos;1.3.0.v202311130434&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform_root&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_ui.feature.feature.group&apos;, version(&apos;3.3.1900.v202405150145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-engine&apos;, version(&apos;1.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.servlets&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.confluence.ui&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.core.runtime&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.17.400.v20240425-0840&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.5.400.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.13.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.feature.feature.group&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.oauth&apos;, version(&apos;1.1.0.v20190307-0457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.event&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.sourcelookup&apos;, version(&apos;2.0.301.20231030-1438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.win32&apos;, version(&apos;3.5.300.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analysis-common&apos;, version(&apos;9.10.0.v20240221-0830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.group&apos;, version(&apos;2.31.0.v20240314-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.hk2.osgi-resource-locator&apos;, version(&apos;1.0.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.feature.feature.group&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.xml.namespaces.feature.feature.jar&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.ui&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.13.300.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.dash.feature.feature.group&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.bndlib&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.feature.feature.group&apos;, version(&apos;1.3.6.202405280856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde&apos;, version(&apos;3.13.2700.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp_root&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.contract&apos;, version(&apos;1.0.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bndtools.api&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui.launchview&apos;, version(&apos;1.1.500.v20240415-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.refactoring&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.uriresolver&apos;, version(&apos;1.4.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.internet.monitor.core&apos;, version(&apos;1.1.0.v202304050316&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpg&apos;, version(&apos;1.78.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics&apos;, version(&apos;2.9.0.v20230916-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.embedder.node&apos;, version(&apos;1.0.6.202405271237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.ui&apos;, version(&apos;0.12.1.202406131414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;biz.aQute.repository&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.servlet-api&apos;, version(&apos;6.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.apt.core&apos;, version(&apos;2.2.202.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5-h2&apos;, version(&apos;5.2.3.v20230922-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.osgi&apos;, version(&apos;2.12.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5&apos;, version(&apos;1.1.0.v20230423-0417&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.ui&apos;, version(&apos;1.1.0.v20190307-0457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem.util&apos;, version(&apos;2.2.100.v202405122323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.group&apos;, version(&apos;1.1.501.v20230507-1921&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core&apos;, version(&apos;3.21.400.v20240415-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.ffi&apos;, version(&apos;2.2.16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_core.feature.feature.jar&apos;, version(&apos;3.4.0.v202311141839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.hamcrest.core&apos;, version(&apos;2.2.0.v20230809-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-engine&apos;, version(&apos;1.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.9.400.v20240507-1301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.core&apos;, version(&apos;1.2.1400.v202405130132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui&apos;, version(&apos;3.18.400.v20240516-0857&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.wtp.overlay&apos;, version(&apos;1.6.1.20231024-1618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.tracwiki&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.4.300.v20240513-1104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.html&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.ui&apos;, version(&apos;3.9.400.v20240419-1233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.9.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.10.400.v20240415-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.bcoview&apos;, version(&apos;1.2.400.v20240322-0935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.win32&apos;, version(&apos;1.3.400.v20240514-1716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty&apos;, version(&apos;3.9.200.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.5.300.v20240424-1301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.templating&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jdom2&apos;, version(&apos;2.0.6.v20230720-0727&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.snakeyaml.engine&apos;, version(&apos;2.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.constants&apos;, version(&apos;0.10.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ua.ui&apos;, version(&apos;1.3.400.v20240321-1452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.binaryproject&apos;, version(&apos;2.1.203.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.fasterxml.jackson.module.jackson-module-jakarta-xmlbind-annotations&apos;, version(&apos;2.17.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.unixsocket&apos;, version(&apos;0.38.22&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.jar&apos;, version(&apos;1.4.2400.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.tooling.ls.eclipse.commons&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.orbit.xml-apis-ext&apos;, version(&apos;1.0.0.v20230923-0644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.doc.user&apos;, version(&apos;3.15.200.v20240515-0744&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.json&apos;, version(&apos;1.0.0.v201011060100&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.transaction-api&apos;, version(&apos;1.3.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;1.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;slf4j.simple&apos;, version(&apos;2.0.13&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.validation&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.asciidoc&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jboss.tools.m2e.wro4j.core&apos;, version(&apos;1.2.1.202301111328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;1.5.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-beanutils&apos;, version(&apos;1.9.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables&apos;, version(&apos;3.6.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.feature.feature.group&apos;, version(&apos;2.6.1.20240602-2342&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-params&apos;, version(&apos;5.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.jar&apos;, version(&apos;3.15.400.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.jdt&apos;, version(&apos;2.3.500.20240602-2342&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.beans.ui.live&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.core&apos;, version(&apos;1.10.3.v20240221-1216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-codec&apos;, version(&apos;1.16.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme&apos;, version(&apos;1.3.300.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.languageconfiguration&apos;, version(&apos;0.12.1.202406131414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.binaryproject.ui&apos;, version(&apos;2.0.200.20231030-1438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.posix&apos;, version(&apos;3.1.19&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.launching&apos;, version(&apos;3.22.0.v20240424-1830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.telnet.feature.feature.group&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.ws.rs-api&apos;, version(&apos;3.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.7.400.v20240425-0751&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.upnp&apos;, version(&apos;1.2.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.logback&apos;, version(&apos;2.6.1.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console&apos;, version(&apos;3.14.100.v20240429-1358&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz&apos;, version(&apos;1.9.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.jar&apos;, version(&apos;1.1.402.v20231021-2127&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.group&apos;, version(&apos;2.3.1800.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient5.feature.feature.group&apos;, version(&apos;1.1.702.v20231114-1017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.apt.ui&apos;, version(&apos;2.0.402.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.feature.group&apos;, version(&apos;1.2.0.v20210517-0327&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ds.ui&apos;, version(&apos;1.3.400.v20240321-1452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springsource.ide.eclipse.commons.jdk_tools&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.xml&apos;, version(&apos;1.3.4.v201005080400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.3.200.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.coordinator&apos;, version(&apos;1.0.2.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.position&apos;, version(&apos;1.0.1.201505202026&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.server&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.http.whiteboard&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor.lemminx&apos;, version(&apos;2.0.600.20240219-1707&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.docs&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tips.feature.feature.group&apos;, version(&apos;0.4.400.v20240525-0701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.xml&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.feature.group&apos;, version(&apos;3.15.400.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper&apos;, version(&apos;1.2.100.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.view.feature.feature.group&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app&apos;, version(&apos;1.3.400.v20240425-1316&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.9.100.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools&apos;, version(&apos;2.4.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.bcoview.feature.feature.jar&apos;, version(&apos;1.2.400.v20240322-0935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.jersey.core.jersey-common&apos;, version(&apos;3.1.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.jndi&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.ui&apos;, version(&apos;3.15.200.v20240518-1954&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging&apos;, version(&apos;1.2.0.v20180409-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.11.0.v20230507-1923&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5&apos;, version(&apos;5.2.1.v20230802-0806&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.tooling.boot.ls.feature.feature.jar&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry&apos;, version(&apos;1.3.0.v20240213-1427&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;1.5.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.ant&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.provisioning&apos;, version(&apos;1.2.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.control&apos;, version(&apos;5.5.300.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.3.100.v20240514-0729&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.feature.feature.jar&apos;, version(&apos;1.3.6.202405280856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.editor&apos;, version(&apos;2.0.401.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.core&apos;, version(&apos;1.3.0.v202401292331&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.compat&apos;, version(&apos;3.1.9.v20240115-1636&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.group&apos;, version(&apos;1.7.200.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.x86asm&apos;, version(&apos;1.0.2.v20230715-0746&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64&apos;, version(&apos;3.126.0.v20240528-0813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;slf4j.api&apos;, version(&apos;2.0.13&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.group&apos;, version(&apos;3.14.1900.v20230715-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.feature.jar&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core&apos;, version(&apos;3.8.500.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.commons&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.namespace.extender&apos;, version(&apos;1.0.1.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.themes&apos;, version(&apos;1.2.2400.v20240213-1133&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.tooling.jdt.ls.commons&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jboss.tools.m2e.wro4j.feature.feature.group&apos;, version(&apos;1.2.1.202301111328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.group&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache.feature.jar&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.markdown.ui&apos;, version(&apos;4.3.0.v20240601-0538&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui&apos;, version(&apos;3.10.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache.feature.group&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search&apos;, version(&apos;3.16.200.v20240426-0859&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier&apos;, version(&apos;0.17.500.v20240419-1233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc.feature.group&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.wizard&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.annotations.core&apos;, version(&apos;1.2.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.12.100.v20240524-2011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.25.100.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.service.api&apos;, version(&apos;1.2.2.v20231218-2126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core&apos;, version(&apos;9.10.0.v20240221-0830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.discovery&apos;, version(&apos;1.3.300.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.event&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.markdown&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.lfs.feature.jar&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.discovery&apos;, version(&apos;1.3.600.v202405150145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.feature.jar&apos;, version(&apos;3.1.9.v20240115-1636&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.gitflow.feature.feature.group&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.modulecore&apos;, version(&apos;1.3.200.v202108200212&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.18.300.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.launching&apos;, version(&apos;2.0.602.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors&apos;, version(&apos;3.17.300.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.annotation.versioning&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.dash.docker&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools&apos;, version(&apos;1.3.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.useradmin&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.project.facet.core&apos;, version(&apos;1.13.100.v202405122323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.fproj.enablement.jdt.feature.jar&apos;, version(&apos;3.30.0.v202405122323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.preview.adapter&apos;, version(&apos;1.2.100.v202401292308&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.measurement&apos;, version(&apos;1.0.2.201802012109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-suite-commons&apos;, version(&apos;1.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper&apos;, version(&apos;1.2.2.202405280856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.3.200.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.7.300.v20231104-1118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.classic&apos;, version(&apos;1.5.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.group&apos;, version(&apos;1.6.2.v20231021-2127&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.embedder.node.feature.feature.jar&apos;, version(&apos;1.1.2.202405271237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.aries.spifly.dynamic.bundle&apos;, version(&apos;1.3.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.core.win32&apos;, version(&apos;1.10.3.v20240221-1216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.5.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.tooling.ls.eclipse.gotosymbol&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.ui&apos;, version(&apos;3.32.100.v20240524-2038&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.runtime&apos;, version(&apos;3.7.400.v20231214-1952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring&apos;, version(&apos;3.14.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.10.200.v20240425-1316&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.springframework.boot.ide.branding.sts4.ini.win32.win32.x86_64&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.enxio&apos;, version(&apos;0.32.17&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.maven.ide.eclipse.wtp&apos;, version(&apos;1.6.1.20231024-1618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient&apos;, version(&apos;4.5.14&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.logback.feature.feature.jar&apos;, version(&apos;2.6.1.20240411-1743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient5.feature.feature.jar&apos;, version(&apos;1.1.702.v20231114-1017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;1.15.400.v20240502-1134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.6.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.core&apos;, version(&apos;1.5.100.v202405122248&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.launching&apos;, version(&apos;3.13.0.v20240424-1246&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springsource.ide.eclipse.commons.boot.ls&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.core&apos;, version(&apos;0.12.1.202406131414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.5.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tips.json&apos;, version(&apos;0.3.400.v20240525-0701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.feature.jar&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.xml.namespaces&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.jca&apos;, version(&apos;1.2.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springsource.ide.eclipse.commons.frameworks.ui&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.manipulation&apos;, version(&apos;1.21.100.v20240524-2038&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.5.300.v20240423-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.apache-el&apos;, version(&apos;9.0.83&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.19.100.v20240524-2011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit&apos;, version(&apos;3.16.400.v20240524-2038&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.hk2.api&apos;, version(&apos;3.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.xml.bind&apos;, version(&apos;2.3.3.v20201118-1818&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.core.ui&apos;, version(&apos;2.0.801.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.model.edit&apos;, version(&apos;2.0.500.20240417-1957&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.jar&apos;, version(&apos;2.31.0.v20240314-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.feature.feature.jar&apos;, version(&apos;3.34.0.v202405180407&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.feature.feature.jar&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.feature.feature.jar&apos;, version(&apos;2.6.1.20240602-2342&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.help.ui&apos;, version(&apos;1.10.3.v20240221-1216&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.1.103.v20230705-0614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.tomcat.core&apos;, version(&apos;1.2.700.v202405150145&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.12.400.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.win32&apos;, version(&apos;6.1.100.202402230238&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.common.fproj.enablement.jdt.feature.group&apos;, version(&apos;3.30.0.v202405122323&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.jar&apos;, version(&apos;1.4.2400.v20240519-2013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.fproj.feature.group&apos;, version(&apos;3.7.4.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.docker.client&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-platform-commons&apos;, version(&apos;1.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.4.300.v20240511-1722&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.xml&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.group&apos;, version(&apos;4.32.0.v20240528-0813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.34.0.v20240502-1134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.jdt.ui&apos;, version(&apos;2.0.401.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_userdoc.feature.feature.jar&apos;, version(&apos;3.3.300.v201901310132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.junit.core&apos;, version(&apos;3.13.200.v20240524-2038&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.control.feature.feature.jar&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed&apos;, version(&apos;3.10.300.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.group&apos;, version(&apos;2.37.0.v20240203-0859&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.core&apos;, version(&apos;1.11.0.v202311141839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools&apos;, version(&apos;3.6.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.14.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.jersey.inject.jersey-hk2&apos;, version(&apos;3.1.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j.debug&apos;, version(&apos;0.23.1.v20240521-1815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.genericeditor&apos;, version(&apos;1.3.400.v20240511-1105&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.main.feature.feature.jar&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xml.resolver&apos;, version(&apos;1.2.0.v20230928-1222&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans&apos;, version(&apos;1.10.300.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.genericeditor.diff.extension&apos;, version(&apos;1.2.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.device&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.launching&apos;, version(&apos;1.4.400.v20240413-1649&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jboss.tools.m2e.wro4j.feature.feature.jar&apos;, version(&apos;1.2.1.202301111328&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.main.feature.feature.group&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.util&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;75.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.api.tools.annotations&apos;, version(&apos;1.3.0.v20240207-2106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4e&apos;, version(&apos;0.18.11.202406071443&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mandas.docker-client&apos;, version(&apos;7.0.8&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring&apos;, version(&apos;3.13.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.maven.pom&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.local.feature.feature.group&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-io&apos;, version(&apos;2.13.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.activation&apos;, version(&apos;1.2.2.v20221203-1659&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4j&apos;, version(&apos;0.23.1.v20240521-1815&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.ui&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;1.4.100.v20231201-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.main.feature_root&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server_adapters.feature.feature.group&apos;, version(&apos;3.34.0.v202405180407&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.headless.build.manager&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.http.apache&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache.agent&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.group&apos;, version(&apos;1.1.402.v20231021-2127&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcutil&apos;, version(&apos;1.78.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.sshd.sftp&apos;, version(&apos;2.12.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker&apos;, version(&apos;1.4.300.v20240514-1422&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.jxpath&apos;, version(&apos;1.3.0.v200911051830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;2.4.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.gpg.bc.feature.jar&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.feature.feature.group&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wildwebdeveloper.xml&apos;, version(&apos;1.3.4.202405270639&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.ssl&apos;, version(&apos;1.3.0.v20230507-1921&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.chabicht.code_intelligence.feature.feature.group&apos;, version(&apos;1.0.0.202506262339&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.feature.group&apos;, version(&apos;1.10.3.v20240228-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor&apos;, version(&apos;3.17.400.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.jar&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.6.800.v20240513-1750&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.jar&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources&apos;, version(&apos;3.9.300.v20240506-0929&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.lfs.server&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.core&apos;, version(&apos;3.18.100.v20240531-0649&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.telnet&apos;, version(&apos;4.8.100.202312281935&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal&apos;, version(&apos;3.5.400.v20240414-1916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.repository&apos;, version(&apos;1.1.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.springframework.boot.ide.branding.sts4.configuration&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations&apos;, version(&apos;1.8.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-compress&apos;, version(&apos;1.26.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.tomcat.ui&apos;, version(&apos;1.1.1100.v202307100353&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.mediawiki&apos;, version(&apos;4.3.0.v20240602-0603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.8.300.v20240207-1054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt&apos;, version(&apos;3.19.500.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core&apos;, version(&apos;3.7.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.30.0.v20240314-0928&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclientjava&apos;, version(&apos;2.0.200.v20231114-1017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.refactoring&apos;, version(&apos;2.0.303.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.branding&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.gitflow.feature.feature.jar&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.wtp&apos;, version(&apos;1.6.1.20231024-1618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.12.600.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.feature.jar&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component.annotations&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4e.debug&apos;, version(&apos;0.15.8.202405212039&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.twiki.ui&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server.http.ui&apos;, version(&apos;1.0.500.v202007170127&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.10.400.v20240426-1040&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.9.200.v20240429-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.126.0.v20240528-0813&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;1.1.400.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.5.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jem&apos;, version(&apos;2.1.0.v202307260438&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet-api&apos;, version(&apos;4.0.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.15.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tips.ui&apos;, version(&apos;0.3.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-migrationsupport&apos;, version(&apos;5.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;io.projectreactor.reactor-core&apos;, version(&apos;3.3.1.202211021051-RELEASE&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.preview.adapter&apos;, version(&apos;1.2.200.v202405180407&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.13.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.jersey.ext.jersey-entity-filtering&apos;, version(&apos;3.1.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.environment&apos;, version(&apos;1.1.0.v202308161955&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jcodings&apos;, version(&apos;1.0.58.v20230703-0749&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.14.400.v20240427-1520&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.quicklinks&apos;, version(&apos;1.2.400.v20240414-1916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.group&apos;, version(&apos;4.32.0.v20240601-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.doc&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;junit-jupiter-api&apos;, version(&apos;5.10.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.junit.runtime&apos;, version(&apos;3.8.100.v20240130-1723&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.cdt.core.native&apos;, version(&apos;6.3.400.202404270026&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.aopalliance&apos;, version(&apos;1.0.0.v20230720-0728&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.12.0.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.webapp&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet&apos;, version(&apos;1.8.200.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.annotation.bundle&apos;, version(&apos;2.0.0.202202082230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.feature.feature.jar&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.mavenarchiver&apos;, version(&apos;2.0.501.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.codegen&apos;, version(&apos;2.23.0.v20230211-1150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclientjava.feature.feature.group&apos;, version(&apos;2.0.200.v20231114-1017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.boot.ide.branding.feature.feature.group&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.epp.mpc.ui&apos;, version(&apos;1.10.3.v20240228-1000&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.annotation&apos;, version(&apos;1.3.5.v20200909-1856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.example.projectdumper&apos;, version(&apos;1.0.0.202509021322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xerces&apos;, version(&apos;2.12.2.v20230928-1306&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;configure.logback.classic&apos;, version(&apos;2.6.1.20240411-1743&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.5.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bndtools.templates.template&apos;, version(&apos;7.0.0.202310060912&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.gitflow.ui&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.debug.ui&apos;, version(&apos;3.13.400.v20240516-0950&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.lsp4e.jdt&apos;, version(&apos;0.13.0.202402070603&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs&apos;, version(&apos;1.5.0.v20240424-0957&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.1000.v20240507-1834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.editor.ls.feature.feature.group&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javassist&apos;, version(&apos;3.30.2.GA&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.common.core&apos;, version(&apos;1.4.100.v202103232321&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.jersey.core.jersey-client&apos;, version(&apos;3.1.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.springframework.boot.ide.branding.sts4.application&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath&apos;, version(&apos;0.4.300.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.22.200.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application&apos;, version(&apos;1.5.400.v20240416-0658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.github.jnr.jffi&apos;, version(&apos;1.3.13&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.pde.bnd.ui&apos;, version(&apos;1.1.0.v20240404-1230&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;net.i2p.crypto.eddsa&apos;, version(&apos;0.3.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.wtp.overlay.ui&apos;, version(&apos;1.6.1.20231024-1618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.sse.ui&apos;, version(&apos;1.7.1000.v202404170147&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.archetype.catalog&apos;, version(&apos;3.2.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.internet.monitor.ui&apos;, version(&apos;1.0.801.v202308110227&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springsource.ide.eclipse.commons.ui&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.6.800.v20240513-1750&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.jersey.media.jersey-media-json-jackson&apos;, version(&apos;3.1.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant&apos;, version(&apos;1.10.14.v20230922-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.1000.v20240507-1834&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.glassfish.hk2.locator&apos;, version(&apos;3.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.core&apos;, version(&apos;1.5.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.group&apos;, version(&apos;2.4.2400.v20240519-2013&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.discovery&apos;, version(&apos;2.0.202.20240411-1122&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcprov&apos;, version(&apos;1.78.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.google.guava&apos;, version(&apos;33.2.0.jre&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jgit.ssh.apache&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.server_adapters.feature.feature.group&apos;, version(&apos;3.34.0.v202405181536&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.4.300.v20240419-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.37.0.v20231208-1346&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springsource.ide.eclipse.commons.frameworks.core&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.wst.web&apos;, version(&apos;1.3.200.v202305221615&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.egit.ui&apos;, version(&apos;6.10.0.202406032230-r&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.linuxtools.docker.editor.ls.feature.feature.jar&apos;, version(&apos;5.15.0.202406032109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.function&apos;, version(&apos;1.2.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springsource.ide.eclipse.commons.core&apos;, version(&apos;4.23.1.202406141939&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.progress&apos;, version(&apos;0.4.400.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.osgi&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.trace&apos;, version(&apos;1.3.300.v20231215-1019&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.gradle.toolingapi&apos;, version(&apos;8.1.1.v20240115-1636&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee.web&apos;, version(&apos;1.3.100.v202405180517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.server.ui&apos;, version(&apos;1.1.500.v202308172116&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.ee8.annotations&apos;, version(&apos;12.0.9&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;1.6.300.v20231201-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport&apos;, version(&apos;1.4.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.registry&apos;, version(&apos;0.12.1.202406131414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.m2e.lemminx.feature.feature.group&apos;, version(&apos;2.0.600.20240219-1707&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm4e.language_pack&apos;, version(&apos;0.12.0.202405210827&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclientjava.feature.feature.jar&apos;, version(&apos;2.0.200.v20231114-1017&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.tm.terminal.connector.telnet.feature.feature.jar&apos;, version(&apos;11.6.0.202403071917&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.buildship.core&apos;, version(&apos;3.1.9.v20240115-1636&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.mylyn.wikitext.textile.ui&apos;, version(&apos;4.3.0.v20240509-0539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.googlecode.javaewah.JavaEWAH&apos;, version(&apos;1.2.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jst.j2ee&apos;, version(&apos;1.2.1100.v202405180414&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.springframework.ide.eclipse.boot.dash&apos;, version(&apos;4.23.1.202406150140&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='com.chabicht.code_intelligence.feature.feature.group' version='1.0.0.202506262339' singleton='false'>
      <update id='com.chabicht.code_intelligence.feature.feature.group' range='[0.0.0,1.0.0.202506262339)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Code Intelligence'/>
        <property name='org.eclipse.equinox.p2.description' value='AI powered coding tools.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://github.com/chabicht/code-intelligence'/>
        <property name='org.eclipse.equinox.p2.provider' value='chabicht.com'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.chabicht.code_intelligence.feature.feature.group' version='1.0.0.202506262339'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.chabicht.code-intelligence' range='[1.0.0.202506262339,1.0.0.202506262339]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.collections' range='[3.2.2.v201511171945,3.2.2.v201511171945]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-beanutils' range='[1.9.4,1.9.4]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.commons-io' range='[2.13.0,2.13.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.chabicht.code_intelligence.feature.feature.jar' range='[1.0.0.202506262339,1.0.0.202506262339]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.txt' url='https://www.eclipse.org/org/documents/epl-2.0/EPL-2.0.txt'>
          Eclipse Public License - v 2.0&#xA;&#xA;  THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE&#xA;  PUBLIC LICENSE (&quot;AGREEMENT&quot;). ANY USE, REPRODUCTION OR&#xA;  DISTRIBUTION&#xA;  OF THE PROGRAM CONSTITUTES RECIPIENT&apos;S ACCEPTANCE OF THIS&#xA;  AGREEMENT.&#xA;&#xA;  1. DEFINITIONS&#xA;&#xA;  &quot;Contribution&quot; means:&#xA;&#xA;  a) in the case of the initial Contributor, the initial content&#xA;  Distributed under this Agreement, and&#xA;&#xA;  b) in the case of each subsequent Contributor:&#xA;  i) changes to the Program, and&#xA;  ii) additions to the Program;&#xA;  where such changes and/or additions to the Program originate from&#xA;  and are Distributed by that particular Contributor. A Contribution&#xA;  &quot;originates&quot; from a Contributor if it was added to the Program&#xA;  by&#xA;  such Contributor itself or anyone acting on such Contributor&apos;s&#xA;  behalf.&#xA;  Contributions do not include changes or additions to the Program that&#xA;  are not Modified Works.&#xA;&#xA;  &quot;Contributor&quot; means any person or entity that Distributes the&#xA;  Program.&#xA;&#xA;  &quot;Licensed Patents&quot; mean patent claims licensable by a&#xA;  Contributor which&#xA;  are necessarily infringed by the use or sale of its Contribution alone&#xA;  or when combined with the Program.&#xA;&#xA;  &quot;Program&quot; means the Contributions Distributed in accordance&#xA;  with this&#xA;  Agreement.&#xA;&#xA;  &quot;Recipient&quot; means anyone who receives the Program under this&#xA;  Agreement&#xA;  or any Secondary License (as applicable), including Contributors.&#xA;  &quot;Derivative Works&quot; shall mean any work, whether in Source Code&#xA;  or other&#xA;  form, that is based on (or derived from) the Program and for which the&#xA;  editorial revisions, annotations, elaborations, or other modifications&#xA;  represent, as a whole, an original work of authorship.&#xA;&#xA;  &quot;Modified Works&quot; shall mean any work in Source Code or other&#xA;  form that&#xA;  results from an addition to, deletion from, or modification of the&#xA;  contents of the Program, including, for purposes of clarity any new file&#xA;  in Source Code form that contains any contents of the Program. Modified&#xA;  Works shall not include works that contain only declarations,&#xA;  interfaces, types, classes, structures, or files of the Program solely&#xA;  in each case in order to link to, bind by name, or subclass the Program&#xA;  or Modified Works thereof.&#xA;&#xA;  &quot;Distribute&quot; means the acts of a) distributing or b) making&#xA;  available&#xA;  in any manner that enables the transfer of a copy.&#xA;&#xA;  &quot;Source Code&quot; means the form of a Program preferred for making&#xA;  modifications, including but not limited to software source code,&#xA;  documentation source, and configuration files.&#xA;&#xA;  &quot;Secondary License&quot; means either the GNU General Public&#xA;  License,&#xA;  Version 2.0, or any later versions of that license, including any&#xA;  exceptions or additional permissions as identified by the initial&#xA;  Contributor.&#xA;&#xA;  2. GRANT OF RIGHTS&#xA;&#xA;  a) Subject to the terms of this Agreement, each Contributor hereby&#xA;  grants Recipient a non-exclusive, worldwide, royalty-free copyright&#xA;  license to reproduce, prepare Derivative Works of, publicly display,&#xA;  publicly perform, Distribute and sublicense the Contribution of such&#xA;  Contributor, if any, and such Derivative Works.&#xA;&#xA;  b) Subject to the terms of this Agreement, each Contributor hereby&#xA;  grants Recipient a non-exclusive, worldwide, royalty-free patent&#xA;  license under Licensed Patents to make, use, sell, offer to sell,&#xA;  import and otherwise transfer the Contribution of such Contributor,&#xA;  if any, in Source Code or other form. This patent license shall&#xA;  apply to the combination of the Contribution and the Program if, at&#xA;  the time the Contribution is added by the Contributor, such addition&#xA;  of the Contribution causes such combination to be covered by the&#xA;  Licensed Patents. The patent license shall not apply to any other&#xA;  combinations which include the Contribution. No hardware per se is&#xA;  licensed hereunder.&#xA;&#xA;  c) Recipient understands that although each Contributor grants the&#xA;  licenses to its Contributions set forth herein, no assurances are&#xA;  provided by any Contributor that the Program does not infringe the&#xA;  patent or other intellectual property rights of any other entity.&#xA;  Each Contributor disclaims any liability to Recipient for claims&#xA;  brought by any other entity based on infringement of intellectual&#xA;  property rights or otherwise. As a condition to exercising the&#xA;  rights and licenses granted hereunder, each Recipient hereby&#xA;  assumes sole responsibility to secure any other intellectual&#xA;  property rights needed, if any. For example, if a third party&#xA;  patent license is required to allow Recipient to Distribute the&#xA;  Program, it is Recipient&apos;s responsibility to acquire that license&#xA;  before distributing the Program.&#xA;&#xA;  d) Each Contributor represents that to its knowledge it has&#xA;  sufficient copyright rights in its Contribution, if any, to grant&#xA;  the copyright license set forth in this Agreement.&#xA;&#xA;  e) Notwithstanding the terms of any Secondary License, no&#xA;  Contributor makes additional grants to any Recipient (other than&#xA;  those set forth in this Agreement) as a result of such Recipient&apos;s&#xA;  receipt of the Program under the terms of a Secondary License&#xA;  (if permitted under the terms of Section 3).&#xA;&#xA;  3. REQUIREMENTS&#xA;&#xA;  3.1 If a Contributor Distributes the Program in any form, then:&#xA;&#xA;  a) the Program must also be made available as Source Code, in&#xA;  accordance with section 3.2, and the Contributor must accompany&#xA;  the Program with a statement that the Source Code for the Program&#xA;  is available under this Agreement, and informs Recipients how to&#xA;  obtain it in a reasonable manner on or through a medium customarily&#xA;  used for software exchange; and&#xA;&#xA;  b) the Contributor may Distribute the Program under a license&#xA;  different than this Agreement, provided that such license:&#xA;  i) effectively disclaims on behalf of all other Contributors all&#xA;  warranties and conditions, express and implied, including&#xA;  warranties or conditions of title and non-infringement, and&#xA;  implied warranties or conditions of merchantability and fitness&#xA;  for a particular purpose;&#xA;&#xA;  ii) effectively excludes on behalf of all other Contributors all&#xA;  liability for damages, including direct, indirect, special,&#xA;  incidental and consequential damages, such as lost profits;&#xA;&#xA;  iii) does not attempt to limit or alter the recipients&apos; rights&#xA;  in the Source Code under section 3.2; and&#xA;&#xA;  iv) requires any subsequent distribution of the Program by any&#xA;  party to be under a license that satisfies the requirements&#xA;  of this section 3.&#xA;&#xA;  3.2 When the Program is Distributed as Source Code:&#xA;&#xA;  a) it must be made available under this Agreement, or if the&#xA;  Program (i) is combined with other material in a separate file or&#xA;  files made available under a Secondary License, and (ii) the initial&#xA;  Contributor attached to the Source Code the notice described in&#xA;  Exhibit A of this Agreement, then the Program may be made available&#xA;  under the terms of such Secondary Licenses, and&#xA;&#xA;  b) a copy of this Agreement must be included with each copy of&#xA;  the Program.&#xA;&#xA;  3.3 Contributors may not remove or alter any copyright, patent,&#xA;  trademark, attribution notices, disclaimers of warranty, or limitations&#xA;  of liability (&quot;notices&quot;) contained within the Program from any&#xA;  copy of&#xA;  the Program which they Distribute, provided that Contributors may add&#xA;  their own appropriate notices.&#xA;&#xA;  4. COMMERCIAL DISTRIBUTION&#xA;&#xA;  Commercial distributors of software may accept certain responsibilities&#xA;  with respect to end users, business partners and the like. While this&#xA;  license is intended to facilitate the commercial use of the Program,&#xA;  the Contributor who includes the Program in a commercial product&#xA;  offering should do so in a manner which does not create potential&#xA;  liability for other Contributors. Therefore, if a Contributor includes&#xA;  the Program in a commercial product offering, such Contributor&#xA;  (&quot;Commercial Contributor&quot;) hereby agrees to defend and&#xA;  indemnify every&#xA;  other Contributor (&quot;Indemnified Contributor&quot;) against any&#xA;  losses,&#xA;  damages and costs (collectively &quot;Losses&quot;) arising from claims,&#xA;  lawsuits&#xA;  and other legal actions brought by a third party against the Indemnified&#xA;  Contributor to the extent caused by the acts or omissions of such&#xA;  Commercial Contributor in connection with its distribution of the&#xA;  Program&#xA;  in a commercial product offering. The obligations in this section do not&#xA;  apply to any claims or Losses relating to any actual or alleged&#xA;  intellectual property infringement. In order to qualify, an Indemnified&#xA;  Contributor must: a) promptly notify the Commercial Contributor in&#xA;  writing of such claim, and b) allow the Commercial Contributor to&#xA;  control,&#xA;  and cooperate with the Commercial Contributor in, the defense and any&#xA;  related settlement negotiations. The Indemnified Contributor may&#xA;  participate in any such claim at its own expense.&#xA;&#xA;  For example, a Contributor might include the Program in a commercial&#xA;  product offering, Product X. That Contributor is then a Commercial&#xA;  Contributor. If that Commercial Contributor then makes performance&#xA;  claims, or offers warranties related to Product X, those performance&#xA;  claims and warranties are such Commercial Contributor&apos;s&#xA;  responsibility&#xA;  alone. Under this section, the Commercial Contributor would have to&#xA;  defend claims against the other Contributors related to those&#xA;  performance&#xA;  claims and warranties, and if a court requires any other Contributor to&#xA;  pay any damages as a result, the Commercial Contributor must pay&#xA;  those damages.&#xA;&#xA;  5. NO WARRANTY&#xA;&#xA;  EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, AND TO THE EXTENT&#xA;  PERMITTED BY APPLICABLE LAW, THE PROGRAM IS PROVIDED ON AN &quot;AS&#xA;  IS&quot;&#xA;  BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR&#xA;  IMPLIED INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OR CONDITIONS OF&#xA;  TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A PARTICULAR&#xA;  PURPOSE. Each Recipient is solely responsible for determining the&#xA;  appropriateness of using and distributing the Program and assumes all&#xA;  risks associated with its exercise of rights under this Agreement,&#xA;  including but not limited to the risks and costs of program errors,&#xA;  compliance with applicable laws, damage to or loss of data, programs&#xA;  or equipment, and unavailability or interruption of operations.&#xA;&#xA;  6. DISCLAIMER OF LIABILITY&#xA;&#xA;  EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, AND TO THE EXTENT&#xA;  PERMITTED BY APPLICABLE LAW, NEITHER RECIPIENT NOR ANY CONTRIBUTORS&#xA;  SHALL HAVE ANY LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,&#xA;  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING WITHOUT LIMITATION LOST&#xA;  PROFITS), HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN&#xA;  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)&#xA;  ARISING IN ANY WAY OUT OF THE USE OR DISTRIBUTION OF THE PROGRAM OR THE&#xA;  EXERCISE OF ANY RIGHTS GRANTED HEREUNDER, EVEN IF ADVISED OF THE&#xA;  POSSIBILITY OF SUCH DAMAGES.&#xA;&#xA;  7. GENERAL&#xA;&#xA;  If any provision of this Agreement is invalid or unenforceable under&#xA;  applicable law, it shall not affect the validity or enforceability of&#xA;  the remainder of the terms of this Agreement, and without further&#xA;  action by the parties hereto, such provision shall be reformed to the&#xA;  minimum extent necessary to make such provision valid and enforceable.&#xA;&#xA;  If Recipient institutes patent litigation against any entity&#xA;  (including a cross-claim or counterclaim in a lawsuit) alleging that the&#xA;  Program itself (excluding combinations of the Program with other&#xA;  software&#xA;  or hardware) infringes such Recipient&apos;s patent(s), then such&#xA;  Recipient&apos;s&#xA;  rights granted under Section 2(b) shall terminate as of the date such&#xA;  litigation is filed.&#xA;&#xA;  All Recipient&apos;s rights under this Agreement shall terminate if it&#xA;  fails to comply with any of the material terms or conditions of this&#xA;  Agreement and does not cure such failure in a reasonable period of&#xA;  time after becoming aware of such noncompliance. If all Recipient&apos;s&#xA;  rights under this Agreement terminate, Recipient agrees to cease use&#xA;  and distribution of the Program as soon as reasonably practicable.&#xA;  However, Recipient&apos;s obligations under this Agreement and any&#xA;  licenses&#xA;  granted by Recipient relating to the Program shall continue and survive.&#xA;  Everyone is permitted to copy and distribute copies of this Agreement,&#xA;  but in order to avoid inconsistency the Agreement is copyrighted and&#xA;  may only be modified in the following manner. The Agreement Steward&#xA;  reserves the right to publish new versions (including revisions) of&#xA;  this Agreement from time to time. No one other than the Agreement&#xA;  Steward has the right to modify this Agreement. The Eclipse Foundation&#xA;  is the initial Agreement Steward. The Eclipse Foundation may assign the&#xA;  responsibility to serve as the Agreement Steward to a suitable separate&#xA;  entity. Each new version of the Agreement will be given a distinguishing&#xA;  version number. The Program (including Contributions) may always be&#xA;  Distributed subject to the version of the Agreement under which it was&#xA;  received. In addition, after a new version of the Agreement is&#xA;  published,&#xA;  Contributor may elect to Distribute the Program (including its&#xA;  Contributions) under the new version.&#xA;&#xA;  Except as expressly stated in Sections 2(a) and 2(b) above, Recipient&#xA;  receives no rights or licenses to the intellectual property of any&#xA;  Contributor under this Agreement, whether expressly, by implication,&#xA;  estoppel or otherwise. All rights in the Program not expressly granted&#xA;  under this Agreement are reserved. Nothing in this Agreement is intended&#xA;  to be enforceable by any entity that is not a Contributor or Recipient.&#xA;  No third-party beneficiary rights are created under this Agreement.&#xA;  Exhibit A - Form of Secondary Licenses Notice&#xA;&#xA;  &quot;This Source Code may also be made available under the following&#xA;  Secondary Licenses when the conditions for such availability set forth&#xA;  in the Eclipse Public License, v. 2.0 are satisfied: {name license(s),&#xA;  version(s), and exceptions or additional permissions here}.&quot;&#xA;&#xA;  Simply including a copy of this Agreement, including this Exhibit A&#xA;  is not sufficient to license the Source Code under Secondary Licenses.&#xA;&#xA;  If it is not possible or desirable to put the notice in a particular&#xA;  file, then You may include the notice in a location (such as a LICENSE&#xA;  file in a relevant directory) where a recipient would be likely to&#xA;  look for such a notice.&#xA;&#xA;  You may add additional accurate notices of copyright ownership.
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='org.eclipse.buildship.feature.group' version='3.1.9.v20240115-1636' singleton='false'>
      <update id='org.eclipse.buildship.feature.group' range='[0.0.0,3.1.9.v20240115-1636)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2023 Gradle Inc.'/>
        <property name='df_LT.featureName' value='Buildship: Eclipse Plug-ins for Gradle'/>
        <property name='df_LT.description' value='Buildship: Eclipse Plug-ins for Gradle, provided as part of the Gradle Platform.&#xA;&#xA;Copyright (c) 2023 Gradle Inc.&#xA;For more information, visit our website https://projects.eclipse.org/projects/tools.buildship'/>
        <property name='df_LT.providerName' value='Eclipse Buildship'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.feature.group' version='3.1.9.v20240115-1636'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.compat' range='[3.1.9.v20240115-1636,3.1.9.v20240115-1636]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.core' range='[3.1.9.v20240115-1636,3.1.9.v20240115-1636]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.ui' range='[3.1.9.v20240115-1636,3.1.9.v20240115-1636]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.branding' range='[3.1.9.v20240115-1636,3.1.9.v20240115-1636]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.feature.jar' range='[3.1.9.v20240115-1636,3.1.9.v20240115-1636]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseUrl' url='%25licenseUrl'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.egit.feature.group' version='6.10.0.202406032230-r' singleton='false'>
      <update id='org.eclipse.egit.feature.group' range='[0.0.0,6.10.0.202406032230-r)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://www.eclipse.org/egit/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.egit.feature'/>
        <property name='maven-artifactId' value='org.eclipse.egit'/>
        <property name='maven-version' value='6.10.0.202406032230-r'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2005, 2023 Shawn Pearce, Robin Rosenberg, et.al.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='Git integration for Eclipse'/>
        <property name='df_LT.description' value='Versioning with Git, integration with Gerrit, Gitflow, and Task repositories'/>
        <property name='df_LT.providerName' value='Eclipse EGit'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.group' version='6.10.0.202406032230-r'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.12.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.11.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.6.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='[3.108.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.8.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.11.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.12.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.10.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.6.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.3.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.8.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' range='[6.10.0,6.11.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.gpg.bc.feature.group' range='[6.10.0,6.11.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.http.apache.feature.group' range='[6.10.0,6.11.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.ssh.apache.feature.group' range='[6.10.0,6.11.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.core' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.ui' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.doc' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.jar' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.egit.gitflow.feature.feature.group' version='6.10.0.202406032230-r' singleton='false'>
      <update id='org.eclipse.egit.gitflow.feature.feature.group' range='[0.0.0,6.10.0.202406032230-r)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://www.eclipse.org/egit/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.egit.feature'/>
        <property name='maven-artifactId' value='org.eclipse.egit.gitflow.feature'/>
        <property name='maven-version' value='6.10.0.202406032230-r'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2015, 2023 Max Hohenegger and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='Git integration for Eclipse - Gitflow support'/>
        <property name='df_LT.description' value='GitFlow support for Git integration in Eclipse'/>
        <property name='df_LT.providerName' value='Eclipse EGit'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.gitflow.feature.feature.group' version='6.10.0.202406032230-r'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' range='[6.10.0,6.11.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.core' range='[6.10.0,6.11.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.ui' range='[6.10.0,6.11.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.gitflow' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.gitflow.ui' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.gitflow.feature.feature.jar' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.epp.mpc.feature.group' version='1.10.3.v20240228-1000' singleton='false'>
      <update id='org.eclipse.epp.mpc.feature.group' range='[0.0.0,1.10.3.v20240228-1000)' severity='0'/>
      <properties size='15'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/epp/mpc/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.epp.mpc'/>
        <property name='maven-artifactId' value='org.eclipse.epp.mpc'/>
        <property name='maven-version' value='1.10.3-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='org.eclipse.epp.mpc.node' value='https://marketplace.eclipse.org/content/eclipse-marketplace-client'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010, 2018 The Eclipse Foundation.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License&#xA;v1.0 which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='Marketplace Client'/>
        <property name='df_LT.description' value='Marketplace Client makes all solutions listed on the Eclipse Marketplace available in your Eclipse IDE.&#xA;&#xA;By bringing the Marketplace into Eclipse, MPC offers a workflow for finding and installing a large collection of solutions from a single source through a simplified workflow that does not require users to deal with individual update sites.'/>
        <property name='df_LT.providerName' value='Eclipse Marketplace Client'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.group' version='1.10.3.v20240228-1000'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.discovery.feature.feature.group' range='[1.0.0.v201004,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.userstorage.feature.group' range='[1.1.0,2.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.core' range='[1.10.3.v20240221-1216,1.10.3.v20240221-1216]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.core.win32' range='[1.10.3.v20240221-1216,1.10.3.v20240221-1216]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.ui' range='[1.10.3.v20240228-1000,1.10.3.v20240228-1000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.ui.css' range='[1.10.3.v20240221-1216,1.10.3.v20240221-1216]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.help.ui' range='[1.10.3.v20240221-1216,1.10.3.v20240221-1216]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.jar' range='[1.10.3.v20240228-1000,1.10.3.v20240228-1000]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.user.ui.feature.group' version='2.4.2400.v20240519-2013' singleton='false'>
      <update id='org.eclipse.equinox.p2.user.ui.feature.group' range='[0.0.0,2.4.2400.v20240519-2013)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.platform'/>
        <property name='maven-artifactId' value='org.eclipse.equinox.p2.user.ui'/>
        <property name='maven-version' value='2.4.2400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008, 2013 IBM Corporation and others.'/>
        <property name='df_LT.featureName' value='Equinox p2, Provisioning for IDEs.'/>
        <property name='df_LT.description' value='Eclipse p2 Provisioning Platform for use in IDE related scenarios'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' version='2.4.2400.v20240519-2013'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.group' range='[1.7.200.v20240515-1919,1.7.200.v20240515-1919]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extras.feature.feature.group' range='[1.4.2400.v20240519-2013,1.4.2400.v20240519-2013]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.rcp.feature.feature.group' range='[1.4.2400.v20240515-1919,1.4.2400.v20240515-1919]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' range='[1.3.400.v20240321-1450,1.3.400.v20240321-1450]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.importexport' range='[1.4.400.v20240321-1450,1.4.400.v20240321-1450]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.jar' range='[2.4.2400.v20240519-2013,2.4.2400.v20240519-2013]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.help.feature.group' version='2.3.1800.v20240601-0610' singleton='false'>
      <update id='org.eclipse.help.feature.group' range='[0.0.0,2.3.1800.v20240601-0610)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.help.feature'/>
        <property name='maven-artifactId' value='org.eclipse.help'/>
        <property name='maven-version' value='2.3.1800-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008, 2013 IBM Corporation and others.'/>
        <property name='df_LT.featureName' value='Eclipse Help System'/>
        <property name='df_LT.description' value='Eclipse help system.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' version='2.3.1800.v20240601-0610'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.jetty' range='[3.9.200.v20240321-1445,3.9.200.v20240321-1445]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.registry' range='[1.4.100.v20240321-1445,1.4.100.v20240321-1445]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.servlet' range='[1.8.200.v20240321-1445,1.8.200.v20240321-1445]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper' range='[1.2.100.v20240321-1445,1.2.100.v20240321-1445]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper.registry' range='[1.3.0.v20240213-1427,1.3.0.v20240213-1427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.base' range='[4.4.400.v20240601-0610,4.4.400.v20240601-0610]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.ui' range='[4.7.0.v20240414-1916,4.7.0.v20240414-1916]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.webapp' range='[3.11.400.v20240508-1954,3.11.400.v20240508-1954]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.5.400.v20240413-1529,1.5.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.4.300.v20240419-2334,1.4.300.v20240419-2334]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.jar' range='[2.3.1800.v20240601-0610,2.3.1800.v20240601-0610]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.jdt.bcoview.feature.feature.group' version='1.2.400.v20240322-0935' singleton='false'>
      <update id='org.eclipse.jdt.bcoview.feature.feature.group' range='[0.0.0,1.2.400.v20240322-0935)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Bytecode Outline View'/>
        <property name='org.eclipse.equinox.p2.description' value='Bytecode Outline View'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.jdt.feature'/>
        <property name='maven-artifactId' value='org.eclipse.jdt.bcoview.feature'/>
        <property name='maven-version' value='1.2.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.bcoview.feature.feature.group' version='1.2.400.v20240322-0935'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core' range='3.33.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.ui' range='3.28.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm' range='9.4.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree' range='9.4.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.tree.analysis' range='9.4.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.objectweb.asm.util' range='9.4.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.bcoview' range='[1.2.400.v20240322-0935,1.2.400.v20240322-0935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.bcoview.feature.feature.jar' range='[1.2.400.v20240322-0935,1.2.400.v20240322-0935]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
    </unit>
    <unit id='org.eclipse.jdt.feature.group' version='3.19.500.v20240601-0610' singleton='false'>
      <update id='org.eclipse.jdt.feature.group' range='[0.0.0,3.19.500.v20240601-0610)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.jdt.feature'/>
        <property name='maven-artifactId' value='org.eclipse.jdt'/>
        <property name='maven-version' value='3.19.500-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2020 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='Eclipse Java Development Tools'/>
        <property name='df_LT.description' value='Eclipse Java development tools (binary runtime and user documentation).'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' version='3.19.500.v20240601-0610'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='41'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt' range='[3.19.500.v20240601-0610,3.19.500.v20240601-0610]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.ui' range='[3.9.400.v20240419-1233,3.9.400.v20240419-1233]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.core' range='[3.8.400.v20240326-0804,3.8.400.v20240326-0804]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.ui' range='[3.8.400.v20240321-1252,3.8.400.v20240321-1252]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.pluggable.core' range='[1.4.400.v20240321-1252,1.4.400.v20240321-1252]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.compiler.batch' range='[3.38.0.v20240524-2033,3.38.0.v20240524-2033]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core' range='[3.38.0.v20240528-0618,3.38.0.v20240528-0618]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.formatterapp' range='[1.2.250.v20240311-0615,1.2.250.v20240311-0615]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.annotation' range='[1.2.100.v20240212-1051,1.2.100.v20240212-1051]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.annotation' range='[2.3.0.v20240111-2306,2.3.0.v20240111-2306]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.manipulation' range='[1.21.100.v20240524-2038,1.21.100.v20240524-2038]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug.ui' range='[3.13.400.v20240516-0950,3.13.400.v20240516-0950]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug' range='[3.21.400.v20240418-1414,3.21.400.v20240418-1414]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit' range='[3.16.400.v20240524-2038,3.16.400.v20240524-2038]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit.core' range='[3.13.200.v20240524-2038,3.13.200.v20240524-2038]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit.runtime' range='[3.7.400.v20231214-1952,3.7.400.v20231214-1952]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit4.runtime' range='[1.3.100.v20231214-1952,1.3.100.v20231214-1952]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit5.runtime' range='[1.1.300.v20231214-1952,1.1.300.v20231214-1952]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching' range='[3.22.0.v20240424-1830,3.22.0.v20240424-1830]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.ui' range='[3.32.100.v20240524-2038,3.32.100.v20240524-2038]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit' range='[4.13.2.v20230809-1000,4.13.2.v20230809-1000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.hamcrest.core' range='[2.2.0.v20230809-1000,2.2.0.v20230809-1000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-jupiter-api' range='[5.10.2,5.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-jupiter-engine' range='[5.10.2,5.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-jupiter-migrationsupport' range='[5.10.2,5.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-jupiter-params' range='[5.10.2,5.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-platform-commons' range='[1.10.2,1.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-platform-engine' range='[1.10.2,1.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-platform-launcher' range='[1.10.2,1.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-platform-runner' range='[1.10.2,1.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-platform-suite-api' range='[1.10.2,1.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-platform-suite-commons' range='[1.10.2,1.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-platform-suite-engine' range='[1.10.2,1.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='junit-vintage-engine' range='[5.10.2,5.10.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.opentest4j' range='[1.3.0,1.3.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apiguardian.api' range='[1.1.2,1.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.doc.user' range='[3.15.2200.v20240529-0958,3.15.2200.v20240529-0958]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching.macosx' range='[3.6.300.v20240321-1645,3.6.300.v20240321-1645]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching.ui.macosx' range='[1.4.300.v20240321-1645,1.4.300.v20240321-1645]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.launching' range='[1.4.400.v20240413-1649,1.4.400.v20240413-1649]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.jar' range='[3.19.500.v20240601-0610,3.19.500.v20240601-0610]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.jgit.feature.group' version='6.10.0.202406032230-r' singleton='false'>
      <update id='org.eclipse.jgit.feature.group' range='[0.0.0,6.10.0.202406032230-r)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/jgit/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.jgit.feature'/>
        <property name='maven-artifactId' value='org.eclipse.jgit'/>
        <property name='maven-version' value='6.10.0.202406032230-r'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2005, 2023 Shawn Pearce, Robin Rosenberg, et.al.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Distribution License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/org/documents/edl-v10.html'/>
        <property name='df_LT.featureName' value='Java implementation of Git'/>
        <property name='df_LT.description' value='A pure Java implementation of the Git version control system.'/>
        <property name='df_LT.providerName' value='Eclipse JGit'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' version='6.10.0.202406032230-r'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.archive' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.jar' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.jgit.lfs.feature.group' version='6.10.0.202406032230-r' singleton='false'>
      <update id='org.eclipse.jgit.lfs.feature.group' range='[0.0.0,6.10.0.202406032230-r)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/jgit/'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.jgit.feature'/>
        <property name='maven-artifactId' value='org.eclipse.jgit.lfs'/>
        <property name='maven-version' value='6.10.0.202406032230-r'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2015, 2023 Matthias Sohn et.al.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Distribution License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/org/documents/edl-v10.html'/>
        <property name='df_LT.featureName' value='Java implementation of Git - optional LFS support'/>
        <property name='df_LT.description' value='Optional LFS support.'/>
        <property name='df_LT.providerName' value='Eclipse JGit'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.lfs.feature.group' version='6.10.0.202406032230-r'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' range='[6.10.0,6.11.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.lfs' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.lfs.server' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.lfs.feature.jar' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.jst.server_adapters.ext.feature.feature.group' version='3.4.1000.v202405180431' singleton='false'>
      <update id='org.eclipse.jst.server_adapters.ext.feature.feature.group' range='[0.0.0,3.4.1000.v202405180431)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.webtools.servertools'/>
        <property name='maven-artifactId' value='org.eclipse.jst.server_adapters.ext.feature'/>
        <property name='maven-version' value='3.4.1000-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2006, 2007 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='JST Server Adapters Extensions (Apache Tomcat)'/>
        <property name='df_LT.description' value='Provides the Apache Tomcat server adapter'/>
        <property name='df_LT.providerName' value='Eclipse Web Tools Platform'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server_adapters.ext.feature.feature.group' version='3.4.1000.v202405180431'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server.tomcat.core' range='[1.2.700.v202405150145,1.2.700.v202405150145]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server.tomcat.ui' range='[1.1.1100.v202307100353,1.1.1100.v202307100353]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server_adapters.ext.feature.feature.jar' range='[3.4.1000.v202405180431,3.4.1000.v202405180431]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.jst.server_adapters.feature.feature.group' version='3.34.0.v202405180407' singleton='false'>
      <update id='org.eclipse.jst.server_adapters.feature.feature.group' range='[0.0.0,3.34.0.v202405180407)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.webtools.servertools'/>
        <property name='maven-artifactId' value='org.eclipse.jst.server_adapters.feature'/>
        <property name='maven-version' value='3.34.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2006, 2007 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='JST Server Adapters'/>
        <property name='df_LT.description' value='Provides the Java EE Preview Server adapter'/>
        <property name='df_LT.providerName' value='Eclipse Web Tools Platform'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server_adapters.feature.feature.group' version='3.34.0.v202405180407'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_adapters.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server.preview.adapter' range='[1.2.200.v202405180407,1.2.200.v202405180407]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server_adapters.feature.feature.jar' range='[3.34.0.v202405180407,3.34.0.v202405180407]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.justj.openjdk.hotspot.jre.full.feature.group' version='21.0.3.v20240426-1530' singleton='false'>
      <update id='org.eclipse.justj.openjdk.hotspot.jre.full.feature.group' range='[0.0.0,21.0.3.v20240426-1530)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.justj.features'/>
        <property name='maven-artifactId' value='org.eclipse.justj.openjdk.hotspot.jre.full'/>
        <property name='maven-version' value='21.0.3-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='org.eclipse.justj.model' value='&lt;?xml version=&quot;1.0&quot; encoding=&quot;UTF-8&quot;?&gt;&#xA;&lt;model:JVM xmlns:model=&quot;http://www.eclipse.org/just/2020/Model&quot;&#xA;    name=&quot;openjdk.hotspot.jre.full&quot;&#xA;    label=&quot;Adoptium OpenJDK Hotspot JRE Complete&quot;&#xA;    version=&quot;21.0.3&quot;&gt;&#xA;  &lt;annotation&#xA;      source=&quot;https://www.eclipse.org/justj/Properties&quot;&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.class.version&quot;&gt;&#xA;      &lt;value&gt;65.0&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.runtime.name&quot;&gt;&#xA;      &lt;value&gt;OpenJDK Runtime Environment&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.runtime.version&quot;&gt;&#xA;      &lt;value&gt;21.0.3+9-LTS&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.specification.name&quot;&gt;&#xA;      &lt;value&gt;Java Platform API Specification&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.specification.vendor&quot;&gt;&#xA;      &lt;value&gt;Oracle Corporation&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.specification.version&quot;&gt;&#xA;      &lt;value&gt;21&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vendor&quot;&gt;&#xA;      &lt;value&gt;Eclipse Adoptium&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vendor.url&quot;&gt;&#xA;      &lt;value&gt;https://adoptium.net/&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vendor.url.bug&quot;&gt;&#xA;      &lt;value&gt;https://github.com/adoptium/adoptium-support/issues&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vendor.version&quot;&gt;&#xA;      &lt;value&gt;Temurin-21.0.3+9&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.version&quot;&gt;&#xA;      &lt;value&gt;21.0.3&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.version.date&quot;&gt;&#xA;      &lt;value&gt;2024-04-16&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vm.info&quot;&gt;&#xA;      &lt;value&gt;mixed mode&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vm.name&quot;&gt;&#xA;      &lt;value&gt;OpenJDK 64-Bit Server VM&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vm.specification.name&quot;&gt;&#xA;      &lt;value&gt;Java Virtual Machine Specification&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vm.specification.vendor&quot;&gt;&#xA;      &lt;value&gt;Oracle Corporation&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vm.specification.version&quot;&gt;&#xA;      &lt;value&gt;21&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vm.vendor&quot;&gt;&#xA;      &lt;value&gt;Eclipse Adoptium&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;java.vm.version&quot;&gt;&#xA;      &lt;value&gt;21.0.3+9-LTS&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.eclipse.justj.description&quot;&gt;&#xA;      &lt;value&gt;Provides the complete set of modules of the JDK, excluding incubators.&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.eclipse.justj.jlink.args&quot;&gt;&#xA;      &lt;value&gt;--compress=2 --vm=server&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.eclipse.justj.label&quot;&gt;&#xA;      &lt;value&gt;Adoptium OpenJDK Hotspot JRE Complete&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.eclipse.justj.name&quot;&gt;&#xA;      &lt;value&gt;openjdk.hotspot.jre.full&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.eclipse.justj.url.vendor&quot;&gt;&#xA;      &lt;value&gt;https://adoptium.net/&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.osgi.framework.system.capabilities&quot;&gt;&#xA;      &lt;value&gt;osgi.ee; osgi.ee=&amp;quot;OSGi/Minimum&amp;quot;; version:List&amp;lt;Version&gt;=&amp;quot;1.0, 1.1, 1.2&amp;quot;, osgi.ee; osgi.ee=&amp;quot;JRE&amp;quot;; version:List&amp;lt;Version&gt;=&amp;quot;1.0, 1.1&amp;quot;, osgi.ee; osgi.ee=&amp;quot;JavaSE&amp;quot;; version:List&amp;lt;Version&gt;=&amp;quot;1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0&amp;quot;,osgi.ee; osgi.ee=&amp;quot;JavaSE/compact1&amp;quot;; version:List&amp;lt;Version&gt;=&amp;quot;1.8, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0&amp;quot;,osgi.ee; osgi.ee=&amp;quot;JavaSE/compact2&amp;quot;; version:List&amp;lt;Version&gt;=&amp;quot;1.8, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0&amp;quot;,osgi.ee; osgi.ee=&amp;quot;JavaSE/compact3&amp;quot;; version:List&amp;lt;Version&gt;=&amp;quot;1.8, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0&amp;quot;&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.osgi.framework.system.packages&quot;&gt;&#xA;      &lt;value&gt;com.sun.java.accessibility.util, com.sun.jdi, com.sun.jdi.connect, com.sun.jdi.connect.spi, com.sun.jdi.event, com.sun.jdi.request, com.sun.management, com.sun.net.httpserver, com.sun.net.httpserver.spi, com.sun.nio.file, com.sun.nio.sctp, com.sun.security.auth, com.sun.security.auth.callback, com.sun.security.auth.login, com.sun.security.auth.module, com.sun.security.jgss, com.sun.source.doctree, com.sun.source.tree, com.sun.source.util, com.sun.tools.attach, com.sun.tools.attach.spi, com.sun.tools.javac, com.sun.tools.jconsole, java.applet, java.awt, java.awt.color, java.awt.datatransfer, java.awt.desktop, java.awt.dnd, java.awt.event, java.awt.font, java.awt.geom, java.awt.im, java.awt.im.spi, java.awt.image, java.awt.image.renderable, java.awt.print, java.beans, java.beans.beancontext, java.io, java.lang, java.lang.annotation, java.lang.constant, java.lang.foreign, java.lang.instrument, java.lang.invoke, java.lang.management, java.lang.module, java.lang.ref, java.lang.reflect, java.lang.runtime, java.math, java.net, java.net.http, java.net.spi, java.nio, java.nio.channels, java.nio.channels.spi, java.nio.charset, java.nio.charset.spi, java.nio.file, java.nio.file.attribute, java.nio.file.spi, java.rmi, java.rmi.dgc, java.rmi.registry, java.rmi.server, java.security, java.security.cert, java.security.interfaces, java.security.spec, java.sql, java.text, java.text.spi, java.time, java.time.chrono, java.time.format, java.time.temporal, java.time.zone, java.util, java.util.concurrent, java.util.concurrent.atomic, java.util.concurrent.locks, java.util.function, java.util.jar, java.util.logging, java.util.prefs, java.util.random, java.util.regex, java.util.spi, java.util.stream, java.util.zip, javax.accessibility, javax.annotation.processing, javax.crypto, javax.crypto.interfaces, javax.crypto.spec, javax.imageio, javax.imageio.event, javax.imageio.metadata, javax.imageio.plugins.bmp, javax.imageio.plugins.jpeg, javax.imageio.plugins.tiff, javax.imageio.spi, javax.imageio.stream, javax.lang.model, javax.lang.model.element, javax.lang.model.type, javax.lang.model.util, javax.management, javax.management.loading, javax.management.modelmbean, javax.management.monitor, javax.management.openmbean, javax.management.relation, javax.management.remote, javax.management.remote.rmi, javax.management.timer, javax.naming, javax.naming.directory, javax.naming.event, javax.naming.ldap, javax.naming.ldap.spi, javax.naming.spi, javax.net, javax.net.ssl, javax.print, javax.print.attribute, javax.print.attribute.standard, javax.print.event, javax.rmi.ssl, javax.script, javax.security.auth, javax.security.auth.callback, javax.security.auth.kerberos, javax.security.auth.login, javax.security.auth.spi, javax.security.auth.x500, javax.security.cert, javax.security.sasl, javax.smartcardio, javax.sound.midi, javax.sound.midi.spi, javax.sound.sampled, javax.sound.sampled.spi, javax.sql, javax.sql.rowset, javax.sql.rowset.serial, javax.sql.rowset.spi, javax.swing, javax.swing.border, javax.swing.colorchooser, javax.swing.event, javax.swing.filechooser, javax.swing.plaf, javax.swing.plaf.basic, javax.swing.plaf.metal, javax.swing.plaf.multi, javax.swing.plaf.nimbus, javax.swing.plaf.synth, javax.swing.table, javax.swing.text, javax.swing.text.html, javax.swing.text.html.parser, javax.swing.text.rtf, javax.swing.tree, javax.swing.undo, javax.tools, javax.transaction.xa, javax.xml, javax.xml.catalog, javax.xml.crypto, javax.xml.crypto.dom, javax.xml.crypto.dsig, javax.xml.crypto.dsig.dom, javax.xml.crypto.dsig.keyinfo, javax.xml.crypto.dsig.spec, javax.xml.datatype, javax.xml.namespace, javax.xml.parsers, javax.xml.stream, javax.xml.stream.events, javax.xml.stream.util, javax.xml.transform, javax.xml.transform.dom, javax.xml.transform.sax, javax.xml.transform.stax, javax.xml.transform.stream, javax.xml.validation, javax.xml.xpath, jdk.dynalink, jdk.dynalink.beans, jdk.dynalink.linker, jdk.dynalink.linker.support, jdk.dynalink.support, jdk.javadoc.doclet, jdk.jfr, jdk.jfr.consumer, jdk.jshell, jdk.jshell.execution, jdk.jshell.spi, jdk.jshell.tool, jdk.management.jfr, jdk.net, jdk.nio, jdk.nio.mapmode, jdk.security.jarsigner, jdk.swing.interop, netscape.javascript, org.ietf.jgss, org.w3c.dom, org.w3c.dom.bootstrap, org.w3c.dom.css, org.w3c.dom.events, org.w3c.dom.html, org.w3c.dom.ls, org.w3c.dom.ranges, org.w3c.dom.stylesheets, org.w3c.dom.traversal, org.w3c.dom.views, org.w3c.dom.xpath, org.xml.sax, org.xml.sax.ext, org.xml.sax.helpers, sun.misc, sun.reflect&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;    &lt;detail&#xA;        key=&quot;org.osgi.framework.version&quot;&gt;&#xA;      &lt;value&gt;1.10.0&lt;/value&gt;&#xA;    &lt;/detail&gt;&#xA;  &lt;/annotation&gt;&#xA;  &lt;description&gt;Provides the complete set of modules of the JDK, excluding incubators.&lt;/description&gt;&#xA;  &lt;aboutTextExtra&gt;&#xA;&#xA;    Visit https://eclipse.dev/justj&#xA;&#xA;    Provides Java Runtimes derived from https://adoptium.net/.&#xA;  &lt;/aboutTextExtra&gt;&#xA;&lt;/model:JVM&gt;'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2020 Eclipse contributors and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='JustJ Adoptium OpenJDK Hotspot JRE Complete'/>
        <property name='df_LT.description' value='Contains the plug-ins and fragments for the Adoptium OpenJDK Hotspot JRE Complete.&#xA;Provides the complete set of modules of the JDK, excluding incubators.'/>
        <property name='df_LT.providerName' value='Eclipse JustJ'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.feature.group' version='21.0.3.v20240426-1530'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.linux.aarch64' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.linux.ppc64le' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'>
          <filter>
            (&amp;(osgi.arch=ppc64le)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.linux.x86_64' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.macosx.aarch64' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.macosx.x86_64' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.win32.x86_64' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.full.feature.jar' range='[21.0.3.v20240426-1530,21.0.3.v20240426-1530]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.linuxtools.docker.feature.feature.group' version='5.15.0.202406032109' singleton='false'>
      <update id='org.eclipse.linuxtools.docker.feature.feature.group' range='[0.0.0,5.15.0.202406032109)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%featureDescription'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/linuxtools'/>
        <property name='org.eclipse.equinox.p2.provider' value='%featureProvider'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.linuxtools'/>
        <property name='maven-artifactId' value='org.eclipse.linuxtools.docker.feature'/>
        <property name='maven-version' value='5.15.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright 2014, 2015 Red Hat, Inc.'/>
        <property name='df_LT.featureName' value='Docker Tooling'/>
        <property name='df_LT.featureDescription' value='The Docker Tooling feature provides the ability to manage Docker Images and Containers from within Eclipse.'/>
        <property name='df_LT.featureProvider' value='Eclipse Linux Tools'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.feature.feature.group' version='5.15.0.202406032109'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.editor.ls.feature.feature.group' range='[5.15.0.202406032109,5.15.0.202406032109]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.core' range='[5.15.0.202406032109,5.15.0.202406032109]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.ui' range='[5.15.0.202406032109,5.15.0.202406032109]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.docs' range='[5.15.0.202406032109,5.15.0.202406032109]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.feature.feature.jar' range='[5.15.0.202406032109,5.15.0.202406032109]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(location:http${#58}//download.eclipse.org/linuxtools/update-docker,type:0); org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(location:http${#58}//download.eclipse.org/linuxtools/update-docker,type:1); org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(location:https${#58}//download.eclipse.org/linuxtools/update-docker,type:0,name:Linux Tools Docker Tooling,enabled:false); org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(location:https${#58}//download.eclipse.org/linuxtools/update-docker,type:1,name:Linux Tools Docker Tooling,enabled:false); org.eclipse.equinox.p2.touchpoint.eclipse.removeJvmArg(jvmArg:--add-opens=java.base/java.io=ALL-UNNAMED); org.eclipse.equinox.p2.touchpoint.eclipse.addJvmArg(jvmArg:--add-opens=java.base/java.io=ALL-UNNAMED); org.eclipse.equinox.p2.touchpoint.eclipse.removeJvmArg(jvmArg:--add-opens=java.base/sun.nio.ch=ALL-UNNAMED); org.eclipse.equinox.p2.touchpoint.eclipse.addJvmArg(jvmArg:--add-opens=java.base/sun.nio.ch=ALL-UNNAMED); org.eclipse.equinox.p2.touchpoint.eclipse.removeJvmArg(jvmArg:--add-opens=java.base/java.net=ALL-UNNAMED); org.eclipse.equinox.p2.touchpoint.eclipse.addJvmArg(jvmArg:--add-opens=java.base/java.net=ALL-UNNAMED); org.eclipse.equinox.p2.touchpoint.eclipse.removeJvmArg(jvmArg:--add-opens=java.base/sun.security.ssl=ALL-UNNAMED); org.eclipse.equinox.p2.touchpoint.eclipse.addJvmArg(jvmArg:--add-opens=java.base/sun.security.ssl=ALL-UNNAMED);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.redhat.com' url='http://www.redhat.com'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.group' version='5.15.0.202406032109' singleton='false'>
      <update id='org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.group' range='[0.0.0,5.15.0.202406032109)' severity='0'/>
      <properties size='14'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.eclipse.org/linuxtools'/>
        <property name='org.eclipse.equinox.p2.provider' value='%featureProvider'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.linuxtools'/>
        <property name='maven-artifactId' value='org.eclipse.linuxtools.jdt.docker.launcher.feature'/>
        <property name='maven-version' value='5.15.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2018 Red Hat, Inc and others. All rights reserved.'/>
        <property name='df_LT.featureName' value='JDT Docker Launcher'/>
        <property name='df_LT.description' value='Launch JDT executables in Docker Container'/>
        <property name='df_LT.featureProvider' value='Eclipse Linux Tools'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.group' version='5.15.0.202406032109'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.feature.feature.group' range='4.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.jdt.docker.launcher' range='[1.0.0.202406032109,1.0.0.202406032109]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.jar' range='[5.15.0.202406032109,5.15.0.202406032109]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(location:http${#58}//download.eclipse.org/linuxtools/update-docker,type:0); org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(location:http${#58}//download.eclipse.org/linuxtools/update-docker,type:1); org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(location:https${#58}//download.eclipse.org/linuxtools/update-docker,type:0,name:Linux Tools Docker Tooling,enabled:false); org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(location:https${#58}//download.eclipse.org/linuxtools/update-docker,type:1,name:Linux Tools Docker Tooling,enabled:false);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='http://www.redhat.com' url='http://www.redhat.com'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.feature.feature.group' version='2.6.1.20240602-2342' singleton='false'>
      <update id='org.eclipse.m2e.feature.feature.group' range='[0.0.0,2.6.1.20240602-2342)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.feature'/>
        <property name='maven-version' value='2.6.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008-2021 Sonatype, Inc.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;Sonatype, Inc. - initial API and implementation'/>
        <property name='df_LT.featureName' value='M2E - Maven Integration for Eclipse'/>
        <property name='df_LT.description' value='m2e is a Maven integration in Eclipse. Launching Maven from Eclipse, dependency management and search.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.group' version='2.6.1.20240602-2342'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.group' range='[2.0.600.20240219-1707,2.0.600.20240219-1707]' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.common' range='[3.2.104,3.2.104]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.catalog' range='[3.2.1.2,3.2.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.descriptor' range='[3.2.1.2,3.2.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.archetype.maven-artifact-transfer' range='[0.13.1.2,0.13.1.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.model.edit' range='[2.0.500.20240417-1957,2.0.500.20240417-1957]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.core' range='[2.6.1.20240602-2342,2.6.1.20240602-2342]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.launching' range='[2.0.602.20240411-1122,2.0.602.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.workspace.cli' range='[0.3.1,0.3.1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.jdt' range='[2.3.500.20240602-2342,2.3.500.20240602-2342]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.editor' range='[2.0.401.20240411-1122,2.0.401.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.maven.runtime' range='[3.9.700.20240602-2313,3.9.700.20240602-2313]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.refactoring' range='[2.0.303.20240411-1122,2.0.303.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.discovery' range='[2.0.202.20240411-1122,2.0.202.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.core.ui' range='[2.0.801.20240411-1122,2.0.801.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.scm' range='[2.0.202.20240411-1122,2.0.202.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.jdt.ui' range='[2.0.401.20240411-1122,2.0.401.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.profiles.core' range='[2.1.202.20240411-1122,2.1.202.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.profiles.ui' range='[2.0.302.20240411-1122,2.0.302.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.sourcelookup' range='[2.0.301.20231030-1438,2.0.301.20231030-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.sourcelookup.ui' range='[2.0.401.20240411-1122,2.0.401.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.binaryproject' range='[2.1.203.20240411-1122,2.1.203.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.binaryproject.ui' range='[2.0.200.20231030-1438,2.0.200.20231030-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.apt.core' range='[2.2.202.20240411-1122,2.2.202.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.apt.ui' range='[2.0.402.20240411-1122,2.0.402.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.mavenarchiver' range='[2.0.501.20240411-1122,2.0.501.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.jar' range='[2.6.1.20240602-2342,2.6.1.20240602-2342]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:https${#58}//download.eclipse.org/technology/m2e/releases/latest,name:Eclipse IDE integration for Maven,enabled:true); org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:https${#58}//download.eclipse.org/technology/m2e/releases/latest,name:Eclipse IDE integration for Maven,enabled:true);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.lemminx.feature.feature.group' version='2.0.600.20240219-1707' singleton='false'>
      <update id='org.eclipse.m2e.lemminx.feature.feature.group' range='[0.0.0,2.0.600.20240219-1707)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.lemminx.feature'/>
        <property name='maven-version' value='2.0.600-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2020, 2021 Red Hat Inc.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='M2E - POM Editor using LemMinX language server (includes Incubating components)'/>
        <property name='df_LT.description' value='Editor for POM files, relying on Wild Web Developer, Eclipse LemMinX language server and its extension for POM files.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.group' version='2.0.600.20240219-1707'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.editor.lemminx' range='[2.0.600.20240219-1707,2.0.600.20240219-1707]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.jar' range='[2.0.600.20240219-1707,2.0.600.20240219-1707]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.logback.feature.feature.group' version='2.6.1.20240411-1743' singleton='false'>
      <update id='org.eclipse.m2e.logback.feature.feature.group' range='[0.0.0,2.6.1.20240411-1743)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.logback.feature'/>
        <property name='maven-version' value='2.6.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008-2021 Sonatype, Inc.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;Sonatype, Inc. - initial API and implementation'/>
        <property name='df_LT.featureName' value='M2E - SLF4J over Logback Logging'/>
        <property name='df_LT.description' value='slf4j over logback logging configuration for Maven Integration for Eclipse.Includes the optional Maven Console View support for logback logging backend.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback.feature.feature.group' version='2.6.1.20240411-1743'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback.feature.feature.jar' range='[2.6.1.20240411-1743,2.6.1.20240411-1743]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback' range='[2.6.1.20240411-1122,2.6.1.20240411-1122]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='configure.logback.classic' range='[2.6.1.20240411-1743,2.6.1.20240411-1743]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.m2e.wtp.feature.feature.group' version='1.6.1.20231024-1618' singleton='false' generation='2'>
      <update match='providedCapabilities.exists(pc | pc.namespace == &apos;org.eclipse.equinox.p2.iu&apos; &amp;&amp; (pc.name == &apos;org.maven.ide.eclipse.wtp.feature.feature.group&apos; || pc.name == &apos;org.eclipse.m2e.wtp.feature.feature.group&apos; &amp;&amp; pc.version &lt; &apos;1.6.1.20231024-1618&apos;))' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.m2e.wtp'/>
        <property name='maven-artifactId' value='org.eclipse.m2e.wtp.feature'/>
        <property name='maven-version' value='1.6.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008-2022 Sonatype, Inc and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;Sonatype, Inc. - initial API and implementation&#xA;Red Hat, Inc. - Java EE configurators'/>
        <property name='df_LT.featureName' value='m2e-wtp - Maven Integration for WTP'/>
        <property name='df_LT.description' value='m2e project configurators for Eclipse WTP.'/>
        <property name='df_LT.providerName' value='Eclipse.org - m2e-wtp'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.wtp.feature.feature.group' version='1.6.1.20231024-1618'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.group' range='2.0.2'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.wtp.overlay' range='[1.6.1.20231024-1618,1.6.1.20231024-1618]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.fproj.feature.group' range='3.2.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.common.fproj.enablement.jdt.feature.group' range='3.2.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='3.6.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.wtp.overlay.ui' range='[1.6.1.20231024-1618,1.6.1.20231024-1618]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='3.6.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.wtp.feature.feature.jar' range='[1.6.1.20231024-1618,1.6.1.20231024-1618]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.wtp' range='[1.6.1.20231024-1618,1.6.1.20231024-1618]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.group' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.maven.ide.eclipse.wtp' range='[1.6.1.20231024-1618,1.6.1.20231024-1618]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.mylyn.wikitext.feature.feature.group' version='4.3.0.v20240602-0603' singleton='false' generation='2'>
      <update match='providedCapabilities.exists(pc | pc.namespace == &apos;org.eclipse.equinox.p2.iu&apos; &amp;&amp; (pc.name == &apos;org.eclipse.mylyn.wikitext_feature.feature.group&apos; || pc.name == &apos;org.eclipse.mylyn.wikitext.feature.feature.group&apos; &amp;&amp; pc.version ~= range(&apos;[0.0.0,4.3.0.v20240602-0603)&apos;)))' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.mylyn.docs'/>
        <property name='maven-artifactId' value='org.eclipse.mylyn.wikitext.feature'/>
        <property name='maven-version' value='4.3.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2007, 2024 David Green and others. All rights reserved.'/>
        <property name='df_LT.featureName' value='Mylyn WikiText'/>
        <property name='df_LT.description' value='Provides an editor for lightweight markup (wiki text) files supporting AsciiDoc, Confluence, Markdown, MediaWiki, Textile, TracWiki and TWiki.  Extends the Mylyn task editor to create a markup-aware editor.'/>
        <property name='df_LT.providerName' value='Eclipse Mylyn'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.feature.feature.group' version='4.3.0.v20240602-0603'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='21'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.ant' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.osgi' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.asciidoc' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.textile' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.html' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.markdown' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.mediawiki' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.confluence' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tracwiki' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.twiki' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.ui' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.help.ui' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.asciidoc.ui' range='[4.3.0.v20240601-0538,4.3.0.v20240601-0538]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.textile.ui' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.markdown.ui' range='[4.3.0.v20240601-0538,4.3.0.v20240601-0538]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.mediawiki.ui' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.confluence.ui' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tracwiki.ui' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.twiki.ui' range='[4.3.0.v20240509-0539,4.3.0.v20240509-0539]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.feature.feature.jar' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.pde.feature.group' version='3.15.400.v20240601-0610' singleton='false'>
      <update id='org.eclipse.pde.feature.group' range='[0.0.0,3.15.400.v20240601-0610)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.pde'/>
        <property name='maven-artifactId' value='org.eclipse.pde'/>
        <property name='maven-version' value='3.15.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2023 IBM Corporation and others.&#xA;&#xA;This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='Eclipse Plug-in Development Environment'/>
        <property name='df_LT.description' value='Eclipse plug-in development environment.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' version='3.15.400.v20240601-0610'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='29'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='[3.15.0,4.0.0)'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.annotation.versioning' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.annotation.bundle' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.component.annotations' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.osgi.service.metatype.annotations' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.bndtools.templates.template' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='biz.aQute.repository' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='bndtools.jareditor' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde' range='[3.13.2700.v20240601-0610,3.13.2700.v20240601-0610]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.build' range='[3.12.400.v20240515-2132,3.12.400.v20240515-2132]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.core' range='[3.18.100.v20240531-0649,3.18.100.v20240531-0649]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.junit.runtime' range='[3.8.100.v20240130-1723,3.8.100.v20240130-1723]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.runtime' range='[3.8.400.v20240321-1452,3.8.400.v20240321-1452]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui' range='[3.15.200.v20240518-1954,3.15.200.v20240518-1954]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.doc.user' range='[3.15.200.v20240515-0744,3.15.200.v20240515-0744]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ui.templates' range='[3.8.400.v20240321-1452,3.8.400.v20240321-1452]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools' range='[1.3.400.v20240419-1823,1.3.400.v20240419-1823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.annotations' range='[1.3.0.v20240207-2106,1.3.0.v20240207-2106]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.api.tools.ui' range='[1.3.400.v20240416-0657,1.3.400.v20240416-0657]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.core' range='[1.3.400.v20240321-1452,1.3.400.v20240321-1452]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.ui' range='[1.3.400.v20240321-1452,1.3.400.v20240321-1452]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.launching' range='[3.13.0.v20240424-1246,3.13.0.v20240424-1246]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.core' range='[1.3.400.v20240321-1452,1.3.400.v20240321-1452]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ua.ui' range='[1.3.400.v20240321-1452,1.3.400.v20240321-1452]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.trace' range='[1.3.300.v20231215-1019,1.3.300.v20231215-1019]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.ds.annotations' range='[1.3.300.v20240503-2142,1.3.300.v20240503-2142]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.genericeditor.extension' range='[1.2.400.v20240430-0753,1.2.400.v20240430-0753]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.bnd.ui' range='[1.1.0.v20240404-1230,1.1.0.v20240404-1230]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.jar' range='[3.15.400.v20240601-0610,3.15.400.v20240601-0610]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform_root' version='4.32.0.v20240601-0610'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='4.32.0.v20240601-0610'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='4.32.0.v20240601-0610'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp_root' version='4.32.0.v20240601-0610'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='4.32.0.v20240601-0610'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='4.32.0.v20240601-0610'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.tips.feature.feature.group' version='0.4.400.v20240525-0701' singleton='false'>
      <update id='org.eclipse.tips.feature.feature.group' range='[0.0.0,0.4.400.v20240525-0701)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.ui'/>
        <property name='maven-artifactId' value='org.eclipse.tips.feature'/>
        <property name='maven-version' value='0.4.400-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2019, 2020 Wim Jongman, Remain Software'/>
        <property name='df_LT.featureName' value='Tip of the Day UI Feature'/>
        <property name='df_LT.description' value='Contains the Eclipse Tips framework.'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.feature.feature.group' version='0.4.400.v20240525-0701'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.ui' range='[0.3.400.v20240413-1529,0.3.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.core' range='[0.3.400.v20240413-1529,0.3.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.json' range='[0.3.400.v20240525-0701,0.3.400.v20240525-0701]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.ide' range='[0.3.400.v20240413-1529,0.3.400.v20240413-1529]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.feature.feature.jar' range='[0.4.400.v20240525-0701,0.4.400.v20240525-0701]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.tm.terminal.feature.feature.group' version='11.6.0.202403071917' singleton='false'>
      <update id='org.eclipse.tcf.te.terminals.feature.feature.group' range='(0.0.0,11.6.0.202403071917)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.cdt'/>
        <property name='maven-artifactId' value='org.eclipse.tm.terminal.feature'/>
        <property name='maven-version' value='11.6.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2011 - 2018 Wind River Systems, Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/'/>
        <property name='df_LT.featureName' value='TM Terminal'/>
        <property name='df_LT.description' value='An integrated Eclipse View for the local command prompt (console) or remote hosts (SSH, Telnet, Serial). Works on Windows, Linux, Mac and Solaris. Requires Eclipse 3.8.2 or newer and a Java 6 or newer JRE.'/>
        <property name='df_LT.providerName' value='Eclipse CDT'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.feature.feature.group' version='11.6.0.202403071917'/>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tcf.te.terminals.feature.feature.group' version='11.6.0.202403071917'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.connector.local.feature.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.connector.ssh.feature.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.connector.telnet.feature.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.control.feature.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.view.feature.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.feature.feature.jar' range='[11.6.0.202403071917,11.6.0.202403071917]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.wildwebdeveloper.feature.feature.group' version='1.3.6.202405280856' singleton='false'>
      <update id='org.eclipse.wildwebdeveloper.feature.feature.group' range='[0.0.0,1.3.6.202405280856)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%name'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Wild Web Developer project'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.wildwebdeveloper'/>
        <property name='maven-artifactId' value='org.eclipse.wildwebdeveloper.feature'/>
        <property name='maven-version' value='1.3.6-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2017 Red Hat Inc. and others.This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0  which is available at https://www.eclipse.org/legal/epl-2.0/'/>
        <property name='df_LT.name' value='Wild Web Developer HTML, CSS, JSON, Yaml, JavaScript, TypeScript, Node tools'/>
        <property name='df_LT.description' value='Basic editor for Web and Node.js technologies in Eclipse IDE. Relies on Language Servers and TextMate grammars to provide development and debug support for HTML, JavaScript, TypeScript, CSS, Yaml, Angular, and more...'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.feature.feature.group' version='1.3.6.202405280856'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.embedder.node.feature.feature.group' range='[1.1.2.202405271237,1.1.2.202405271237]' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.xml.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper' range='[1.2.2.202405280856,1.2.2.202405280856]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.feature.feature.jar' range='[1.3.6.202405280856,1.3.6.202405280856]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.wildwebdeveloper.xml.feature.feature.group' version='1.3.4.202405270639' singleton='false'>
      <update id='org.eclipse.wildwebdeveloper.xml.feature.feature.group' range='[0.0.0,1.3.4.202405270639)' severity='0'/>
      <properties size='12'>
        <property name='org.eclipse.equinox.p2.name' value='%name'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse Wild Web Developer project'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.wildwebdeveloper'/>
        <property name='maven-artifactId' value='org.eclipse.wildwebdeveloper.xml.feature'/>
        <property name='maven-version' value='1.3.4-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2020 Red Hat Inc. and others.This program and the accompanying materials are made available under the terms of the Eclipse Public License 2.0  which is available at https://www.eclipse.org/legal/epl-2.0/'/>
        <property name='df_LT.name' value='Wild Web Developer XML tools'/>
        <property name='df_LT.description' value='XML editor in Eclipse IDE. Relies on Language Servers and TextMate grammars to provide development and debug support for XML, XSD, DTD and more...'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.xml.feature.feature.group' version='1.3.4.202405270639'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.xml' range='[1.3.4.202405270639,1.3.4.202405270639]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.xml.feature.feature.jar' range='[1.3.4.202405270639,1.3.4.202405270639]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.wst.server_adapters.feature.feature.group' version='3.34.0.v202405181536' singleton='false'>
      <update id='org.eclipse.wst.server_adapters.feature.feature.group' range='[0.0.0,3.34.0.v202405181536)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.webtools.servertools'/>
        <property name='maven-artifactId' value='org.eclipse.wst.server_adapters.feature'/>
        <property name='maven-version' value='3.34.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2007, 2017 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='WST Server Adapters'/>
        <property name='df_LT.description' value='Provides the HTTP Server and HTTP Preview server adapters'/>
        <property name='df_LT.providerName' value='Eclipse Web Tools Platform'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_adapters.feature.feature.group' version='3.34.0.v202405181536'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.preview.adapter' range='[1.2.100.v202401292308,1.2.100.v202401292308]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.jndi' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.xml' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.transaction-api' range='[1.3.3,1.3.3]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.enterprise.cdi-api' range='[2.0.2,2.0.2]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.enterprise.lang-model' range='[4.1.0,4.1.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='jakarta.interceptor-api' range='[1.2.5,1.2.5]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.preview' range='[1.3.0.v202311130434,1.3.0.v202311130434]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.http.core' range='[1.0.400.v202007170127,1.0.400.v202007170127]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.http.ui' range='[1.0.500.v202007170127,1.0.500.v202007170127]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.ee' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.ee8.annotations' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.ee8.jndi' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.ee8.plus' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.plus' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.ee8.servlets' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jetty.ee8.webapp' range='[12.0.9,12.0.9]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_adapters.feature.feature.jar' range='[3.34.0.v202405181536,3.34.0.v202405181536]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.wst.server_ui.feature.feature.group' version='3.3.1900.v202405150145' singleton='false'>
      <update id='org.eclipse.wst.server_ui.feature.feature.group' range='[0.0.0,3.3.1900.v202405150145)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.eclipse.webtools.servertools'/>
        <property name='maven-artifactId' value='org.eclipse.wst.server_ui.feature'/>
        <property name='maven-version' value='3.3.1900-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;April 9, 2014&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;&#x9;- Content may be structured and packaged into modules to facilitate delivering,&#xA;&#x9;  extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;&#x9;  plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;&#x9;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;&#x9;  in a directory named &quot;plugins&quot;.&#xA;&#x9;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;&#x9;  Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;&#x9;  Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;&#x9;  numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;&#x9;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;&#x9;  named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;&#x9;- The top-level (root) directory&#xA;&#x9;- Plug-in and Fragment directories&#xA;&#x9;- Inside Plug-ins and Fragments packaged as JARs&#xA;&#x9;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;&#x9;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;&#x9;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;&#x9;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;&#x9;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;&#x9;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;&#x9;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;&#x9;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;&#x9;   the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;&#x9;   extending or updating the functionality of an Eclipse-based product.&#xA;&#x9;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;&#x9;   Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;&#x9;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;&#x9;   govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;&#x9;   Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;&#x9;   with the Specification. Such Installable Software Agreement must inform the user of the&#xA;&#x9;   terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;&#x9;   the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;&#x9;   indication of agreement by the user, the provisioning Technology will complete installation&#xA;&#x9;   of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2006 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.featureName' value='WST Server UI'/>
        <property name='df_LT.description' value='Server tools framework UI'/>
        <property name='df_LT.providerName' value='Eclipse Web Tools Platform'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_ui.feature.feature.group' version='3.3.1900.v202405150145'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_userdoc.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_core.feature.feature.group' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.internet.monitor.ui' range='[1.0.801.v202308110227,1.0.801.v202308110227]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.ui.infopop' range='[1.1.200.v201901310132,1.1.200.v201901310132]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.ui' range='[1.6.200.v202308172116,1.6.200.v202308172116]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.discovery' range='[1.3.600.v202405150145,1.3.600.v202405150145]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_ui.feature.feature.jar' range='[3.3.1900.v202405150145,3.3.1900.v202405150145]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.jboss.tools.m2e.wro4j.feature.feature.group' version='1.2.1.202301111328' singleton='false'>
      <update id='org.jboss.tools.m2e.wro4j.feature.feature.group' range='[0.0.0,1.2.1.202301111328)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.jboss.tools.m2e.wro4j'/>
        <property name='maven-artifactId' value='org.jboss.tools.m2e.wro4j.feature'/>
        <property name='maven-version' value='1.2.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;delivering, extending, and upgrading the Content. Typical modules may&#xA;include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;(Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;associated material. Each Feature may be packaged as a sub-directory in a&#xA;directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;contain a list of the names and version numbers of the Plug-ins and/or&#xA;Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;intent of installing, extending or updating the functionality of an&#xA;Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;party Installable Software or a portion thereof to be accessed and copied to&#xA;the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;conditions that govern the use of the Installable Software (&quot;Installable&#xA;Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;accessed from the Target Machine in accordance with the Specification. Such&#xA;Installable Software Agreement must inform the user of the terms and&#xA;conditions that govern the Installable Software and must solicit acceptance&#xA;by the end user in the manner prescribed in such Installable&#xA;Software Agreement. Upon such indication of agreement by the user, the&#xA;provisioning Technology will complete installation of the&#xA;Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2012-2022 Red Hat Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License 2.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-2.0/&#xA;&#xA;SPDX-License-Identifier: EPL-2.0'/>
        <property name='df_LT.featureName' value='m2e connector for WRO4J'/>
        <property name='df_LT.description' value='m2e connector for WRO4J'/>
        <property name='df_LT.providerName' value='Red Hat, Inc.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.jboss.tools.m2e.wro4j.feature.feature.group' version='1.2.1.202301111328'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.jboss.tools.m2e.wro4j.core' range='[1.2.1.202301111328,1.2.1.202301111328]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.jboss.tools.m2e.wro4j.ui' range='[1.2.1.202301111328,1.2.1.202301111328]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.jboss.tools.m2e.wro4j.feature.feature.jar' range='[1.2.1.202301111328,1.2.1.202301111328]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.sonatype.m2e.egit.feature.feature.group' version='0.17.0.202209271423' singleton='false'>
      <update id='org.sonatype.m2e.egit.feature.feature.group' range='[0.0.0,0.17.0.202209271423)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='Maven SCM Handler for EGit'/>
        <property name='org.eclipse.equinox.p2.description' value='Checkout Maven projects from Git using EGit.'/>
        <property name='org.eclipse.equinox.p2.description.url' value='https://m2eclipse.sonatype.org/'/>
        <property name='org.eclipse.equinox.p2.provider' value='Takari, Inc.'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.sonatype.m2e.egit'/>
        <property name='maven-artifactId' value='org.sonatype.m2e.egit.feature'/>
        <property name='maven-version' value='0.17.0-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Public License - v 1.0&#xA;&#xA;THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE&#xA;PUBLIC LICENSE (&quot;AGREEMENT&quot;). ANY USE, REPRODUCTION OR DISTRIBUTION OF&#xA;THE PROGRAM CONSTITUTES RECIPIENT&apos;S ACCEPTANCE OF THIS AGREEMENT.&#xA;&#xA;*1. DEFINITIONS*&#xA;&#xA;&quot;Contribution&quot; means:&#xA;&#xA;a) in the case of the initial Contributor, the initial code and&#xA;documentation distributed under this Agreement, and&#xA;&#xA;b) in the case of each subsequent Contributor:&#xA;&#xA;i) changes to the Program, and&#xA;&#xA;ii) additions to the Program;&#xA;&#xA;where such changes and/or additions to the Program originate from and&#xA;are distributed by that particular Contributor. A Contribution&#xA;&apos;originates&apos; from a Contributor if it was added to the Program by such&#xA;Contributor itself or anyone acting on such Contributor&apos;s behalf.&#xA;Contributions do not include additions to the Program which: (i) are&#xA;separate modules of software distributed in conjunction with the Program&#xA;under their own license agreement, and (ii) are not derivative works of&#xA;the Program.&#xA;&#xA;&quot;Contributor&quot; means any person or entity that distributes the Program.&#xA;&#xA;&quot;Licensed Patents&quot; mean patent claims licensable by a Contributor which&#xA;are necessarily infringed by the use or sale of its Contribution alone&#xA;or when combined with the Program.&#xA;&#xA;&quot;Program&quot; means the Contributions distributed in accordance with this&#xA;Agreement.&#xA;&#xA;&quot;Recipient&quot; means anyone who receives the Program under this Agreement,&#xA;including all Contributors.&#xA;&#xA;*2. GRANT OF RIGHTS*&#xA;&#xA;a) Subject to the terms of this Agreement, each Contributor hereby&#xA;grants Recipient a non-exclusive, worldwide, royalty-free copyright&#xA;license to reproduce, prepare derivative works of, publicly display,&#xA;publicly perform, distribute and sublicense the Contribution of such&#xA;Contributor, if any, and such derivative works, in source code and&#xA;object code form.&#xA;&#xA;b) Subject to the terms of this Agreement, each Contributor hereby&#xA;grants Recipient a non-exclusive, worldwide, royalty-free patent license&#xA;under Licensed Patents to make, use, sell, offer to sell, import and&#xA;otherwise transfer the Contribution of such Contributor, if any, in&#xA;source code and object code form. This patent license shall apply to the&#xA;combination of the Contribution and the Program if, at the time the&#xA;Contribution is added by the Contributor, such addition of the&#xA;Contribution causes such combination to be covered by the Licensed&#xA;Patents. The patent license shall not apply to any other combinations&#xA;which include the Contribution. No hardware per se is licensed hereunder.&#xA;&#xA;c) Recipient understands that although each Contributor grants the&#xA;licenses to its Contributions set forth herein, no assurances are&#xA;provided by any Contributor that the Program does not infringe the&#xA;patent or other intellectual property rights of any other entity. Each&#xA;Contributor disclaims any liability to Recipient for claims brought by&#xA;any other entity based on infringement of intellectual property rights&#xA;or otherwise. As a condition to exercising the rights and licenses&#xA;granted hereunder, each Recipient hereby assumes sole responsibility to&#xA;secure any other intellectual property rights needed, if any. For&#xA;example, if a third party patent license is required to allow Recipient&#xA;to distribute the Program, it is Recipient&apos;s responsibility to acquire&#xA;that license before distributing the Program.&#xA;&#xA;d) Each Contributor represents that to its knowledge it has sufficient&#xA;copyright rights in its Contribution, if any, to grant the copyright&#xA;license set forth in this Agreement.&#xA;&#xA;*3. REQUIREMENTS*&#xA;&#xA;A Contributor may choose to distribute the Program in object code form&#xA;under its own license agreement, provided that:&#xA;&#xA;a) it complies with the terms and conditions of this Agreement; and&#xA;&#xA;b) its license agreement:&#xA;&#xA;i) effectively disclaims on behalf of all Contributors all warranties&#xA;and conditions, express and implied, including warranties or conditions&#xA;of title and non-infringement, and implied warranties or conditions of&#xA;merchantability and fitness for a particular purpose;&#xA;&#xA;ii) effectively excludes on behalf of all Contributors all liability for&#xA;damages, including direct, indirect, special, incidental and&#xA;consequential damages, such as lost profits;&#xA;&#xA;iii) states that any provisions which differ from this Agreement are&#xA;offered by that Contributor alone and not by any other party; and&#xA;&#xA;iv) states that source code for the Program is available from such&#xA;Contributor, and informs licensees how to obtain it in a reasonable&#xA;manner on or through a medium customarily used for software exchange.&#xA;&#xA;When the Program is made available in source code form:&#xA;&#xA;a) it must be made available under this Agreement; and&#xA;&#xA;b) a copy of this Agreement must be included with each copy of the Program.&#xA;&#xA;Contributors may not remove or alter any copyright notices contained&#xA;within the Program.&#xA;&#xA;Each Contributor must identify itself as the originator of its&#xA;Contribution, if any, in a manner that reasonably allows subsequent&#xA;Recipients to identify the originator of the Contribution.&#xA;&#xA;*4. COMMERCIAL DISTRIBUTION*&#xA;&#xA;Commercial distributors of software may accept certain responsibilities&#xA;with respect to end users, business partners and the like. While this&#xA;license is intended to facilitate the commercial use of the Program, the&#xA;Contributor who includes the Program in a commercial product offering&#xA;should do so in a manner which does not create potential liability for&#xA;other Contributors. Therefore, if a Contributor includes the Program in&#xA;a commercial product offering, such Contributor (&quot;Commercial&#xA;Contributor&quot;) hereby agrees to defend and indemnify every other&#xA;Contributor (&quot;Indemnified Contributor&quot;) against any losses, damages and&#xA;costs (collectively &quot;Losses&quot;) arising from claims, lawsuits and other&#xA;legal actions brought by a third party against the Indemnified&#xA;Contributor to the extent caused by the acts or omissions of such&#xA;Commercial Contributor in connection with its distribution of the&#xA;Program in a commercial product offering. The obligations in this&#xA;section do not apply to any claims or Losses relating to any actual or&#xA;alleged intellectual property infringement. In order to qualify, an&#xA;Indemnified Contributor must: a) promptly notify the Commercial&#xA;Contributor in writing of such claim, and b) allow the Commercial&#xA;Contributor to control, and cooperate with the Commercial Contributor&#xA;in, the defense and any related settlement negotiations. The Indemnified&#xA;Contributor may participate in any such claim at its own expense.&#xA;&#xA;For example, a Contributor might include the Program in a commercial&#xA;product offering, Product X. That Contributor is then a Commercial&#xA;Contributor. If that Commercial Contributor then makes performance&#xA;claims, or offers warranties related to Product X, those performance&#xA;claims and warranties are such Commercial Contributor&apos;s responsibility&#xA;alone. Under this section, the Commercial Contributor would have to&#xA;defend claims against the other Contributors related to those&#xA;performance claims and warranties, and if a court requires any other&#xA;Contributor to pay any damages as a result, the Commercial Contributor&#xA;must pay those damages.&#xA;&#xA;*5. NO WARRANTY*&#xA;&#xA;EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, THE PROGRAM IS PROVIDED&#xA;ON AN &quot;AS IS&quot; BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,&#xA;EITHER EXPRESS OR IMPLIED INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES&#xA;OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR&#xA;A PARTICULAR PURPOSE. Each Recipient is solely responsible for&#xA;determining the appropriateness of using and distributing the Program&#xA;and assumes all risks associated with its exercise of rights under this&#xA;Agreement , including but not limited to the risks and costs of program&#xA;errors, compliance with applicable laws, damage to or loss of data,&#xA;programs or equipment, and unavailability or interruption of operations.&#xA;&#xA;*6. DISCLAIMER OF LIABILITY*&#xA;&#xA;EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, NEITHER RECIPIENT NOR&#xA;ANY CONTRIBUTORS SHALL HAVE ANY LIABILITY FOR ANY DIRECT, INDIRECT,&#xA;INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING&#xA;WITHOUT LIMITATION LOST PROFITS), HOWEVER CAUSED AND ON ANY THEORY OF&#xA;LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING&#xA;NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OR&#xA;DISTRIBUTION OF THE PROGRAM OR THE EXERCISE OF ANY RIGHTS GRANTED&#xA;HEREUNDER, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.&#xA;&#xA;*7. GENERAL*&#xA;&#xA;If any provision of this Agreement is invalid or unenforceable under&#xA;applicable law, it shall not affect the validity or enforceability of&#xA;the remainder of the terms of this Agreement, and without further action&#xA;by the parties hereto, such provision shall be reformed to the minimum&#xA;extent necessary to make such provision valid and enforceable.&#xA;&#xA;If Recipient institutes patent litigation against any entity (including&#xA;a cross-claim or counterclaim in a lawsuit) alleging that the Program&#xA;itself (excluding combinations of the Program with other software or&#xA;hardware) infringes such Recipient&apos;s patent(s), then such Recipient&apos;s&#xA;rights granted under Section 2(b) shall terminate as of the date such&#xA;litigation is filed.&#xA;&#xA;All Recipient&apos;s rights under this Agreement shall terminate if it fails&#xA;to comply with any of the material terms or conditions of this Agreement&#xA;and does not cure such failure in a reasonable period of time after&#xA;becoming aware of such noncompliance. If all Recipient&apos;s rights under&#xA;this Agreement terminate, Recipient agrees to cease use and distribution&#xA;of the Program as soon as reasonably practicable. However, Recipient&apos;s&#xA;obligations under this Agreement and any licenses granted by Recipient&#xA;relating to the Program shall continue and survive.&#xA;&#xA;Everyone is permitted to copy and distribute copies of this Agreement,&#xA;but in order to avoid inconsistency the Agreement is copyrighted and may&#xA;only be modified in the following manner. The Agreement Steward reserves&#xA;the right to publish new versions (including revisions) of this&#xA;Agreement from time to time. No one other than the Agreement Steward has&#xA;the right to modify this Agreement. The Eclipse Foundation is the&#xA;initial Agreement Steward. The Eclipse Foundation may assign the&#xA;responsibility to serve as the Agreement Steward to a suitable separate&#xA;entity. Each new version of the Agreement will be given a distinguishing&#xA;version number. The Program (including Contributions) may always be&#xA;distributed subject to the version of the Agreement under which it was&#xA;received. In addition, after a new version of the Agreement is&#xA;published, Contributor may elect to distribute the Program (including&#xA;its Contributions) under the new version. Except as expressly stated in&#xA;Sections 2(a) and 2(b) above, Recipient receives no rights or licenses&#xA;to the intellectual property of any Contributor under this Agreement,&#xA;whether expressly, by implication, estoppel or otherwise. All rights in&#xA;the Program not expressly granted under this Agreement are reserved.&#xA;&#xA;This Agreement is governed by the laws of the State of New York and the&#xA;intellectual property laws of the United States of America. No party to&#xA;this Agreement will bring a legal action under this Agreement more than&#xA;one year after the cause of action arose. Each party waives its rights&#xA;to a jury trial in any resulting litigation.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008-2021 Sonatype, Inc.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;Sonatype, Inc. - initial API and implementation'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sonatype.m2e.egit.feature.feature.group' version='0.17.0.202209271423'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sonatype.m2e.egit' range='[0.17.0.202209271423,0.17.0.202209271423]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sonatype.m2e.egit.feature.feature.jar' range='[0.17.0.202209271423,0.17.0.202209271423]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.springframework.boot.ide.branding.sts4' version='4.23.1.202406150140'>
      <update id='org.springframework.boot.ide.branding.sts4' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Spring Tool Suite 4'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.branding.sts4' version='4.23.1.202406150140'/>
      </provides>
      <requires size='40'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.lfs.feature.group' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_adapters.feature.feature.group' range='[3.34.0.v202405181536,3.34.0.v202405181536]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jgit.feature.group' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sonatype.m2e.egit.feature.feature.group' range='[0.17.0.202209271423,0.17.0.202209271423]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.dash.feature.feature.group' range='[4.23.1.202406150140,4.23.1.202406150140]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.springframework.boot.ide.branding.sts4.configuration' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.main.feature.feature.group' range='[4.23.1.202406150140,4.23.1.202406150140]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.xml.namespaces.feature.feature.group' range='[4.23.1.202406150140,4.23.1.202406150140]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.feature.feature.group' range='[2.6.1.20240602-2342,2.6.1.20240602-2342]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.buildship.feature.group' range='[3.1.9.v20240115-1636,3.1.9.v20240115-1636]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server_adapters.ext.feature.feature.group' range='[3.4.1000.v202405180431,3.4.1000.v202405180431]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server_ui.feature.feature.group' range='[3.3.1900.v202405150145,3.3.1900.v202405150145]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.jboss.tools.m2e.wro4j.feature.feature.group' range='[1.2.1.202301111328,1.2.1.202301111328]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.docker.feature.feature.group' range='[5.15.0.202406032109,5.15.0.202406032109]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.feature.group' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.logback.feature.feature.group' range='[2.6.1.20240411-1743,2.6.1.20240411-1743]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.lemminx.feature.feature.group' range='[2.0.600.20240219-1707,2.0.600.20240219-1707]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.tooling.boot.ls.feature.feature.group' range='[4.23.1.202406141939,4.23.1.202406141939]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.xml.feature.feature.group' range='[1.3.4.202405270639,1.3.4.202405270639]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.group' range='[5.15.0.202406032109,5.15.0.202406032109]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='[3.19.500.v20240601-0610,3.19.500.v20240601-0610]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.egit.gitflow.feature.feature.group' range='[6.10.0.202406032230-r,6.10.0.202406032230-r]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.4.2400.v20240519-2013,2.4.2400.v20240519-2013]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.feature.feature.group' range='[4.3.0.v20240602-0603,4.3.0.v20240602-0603]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jst.server_adapters.feature.feature.group' range='[3.34.0.v202405180407,3.34.0.v202405180407]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tm.terminal.feature.feature.group' range='[11.6.0.202403071917,11.6.0.202403071917]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[4.32.0.v20240601-0610,4.32.0.v20240601-0610]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.tips.feature.feature.group' range='[0.4.400.v20240525-0701,0.4.400.v20240525-0701]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.pde.feature.group' range='[3.15.400.v20240601-0610,3.15.400.v20240601-0610]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.group' range='[1.10.3.v20240228-1000,1.10.3.v20240228-1000]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' range='[2.3.1800.v20240601-0610,2.3.1800.v20240601-0610]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.bcoview.feature.feature.group' range='[1.2.400.v20240322-0935,1.2.400.v20240322-0935]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.m2e.wtp.feature.feature.group' range='[1.6.1.20231024-1618,1.6.1.20231024-1618]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.springframework.boot.ide.branding.sts4.application' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.branding.feature.feature.group' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wildwebdeveloper.feature.feature.group' range='[1.3.6.202405280856,1.3.6.202405280856]'>
          <filter>
            (|(org.eclipse.equinox.p2.install.mode.root=true)(org.springframework.boot.ide.branding.sts4.install.mode.root=true))
          </filter>
        </required>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:https${#58}//download.eclipse.org/releases/latest,name:Latest Eclipse Release);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:https${#58}//download.eclipse.org/releases/latest,name:Latest Eclipse Release);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4/update/latest,name:Spring Tool Suite 4);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4/update/latest,name:Spring Tool Suite 4);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4-language-server-integrations,name:Spring Tools 4 Language Servers for Eclipse);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4-language-server-integrations,name:Spring Tools 4 Language Servers for Eclipse);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:https${#58}//download.springsource.com/release/TOOLS/sts4/update/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:https${#58}//download.springsource.com/release/TOOLS/sts4/update/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:https${#58}//download.springsource.com/release/TOOLS/sts4-language-server-integrations);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:https${#58}//download.springsource.com/release/TOOLS/sts4-language-server-integrations);org.eclipse.equinox.p2.touchpoint.natives.mkdir(path:${installFolder}/dropins);
          </instruction>
          <instruction key='unconfigure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:https${#58}//download.eclipse.org/releases/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:https${#58}//download.eclipse.org/releases/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4/update/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4/update/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:https${#58}//download.springsource.com/release/TOOLS/sts4/update/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:https${#58}//download.springsource.com/release/TOOLS/sts4/update/latest);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4-language-server-integrations);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:https${#58}//cdn.spring.io/spring-tools/release/TOOLS/sts4-language-server-integrations);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:https${#58}//download.springsource.com/release/TOOLS/sts4-language-server-integrations);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:https${#58}//download.springsource.com/release/TOOLS/sts4-language-server-integrations);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.springframework.boot.ide.branding.sts4.executable.win32.win32.x86_64' version='4.23.1.202406150140'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.branding.sts4.executable.win32.win32.x86_64' version='4.23.1.202406150140'/>
        <provided namespace='toolingorg.springframework.boot.ide.branding.sts4' name='org.springframework.boot.ide.branding.sts4.executable' version='4.23.1.202406150140'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.springframework.boot.ide.branding.sts4.executable.win32.win32.x86_64' version='4.23.1.202406150140'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.springframework.boot.ide.main.feature.feature.group' version='4.23.1.202406150140' singleton='false'>
      <update id='org.springframework.boot.ide.main.feature.feature.group' range='[0.0.0,4.23.1.202406150140)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='Spring Tool Suite 4 Main Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Broadcom'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.springframework.boot.ide'/>
        <property name='maven-artifactId' value='org.springframework.boot.ide.main.feature'/>
        <property name='maven-version' value='4.23.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='Eclipse Public License - v 1.0&#xA;&#xA;THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE PUBLIC LICENSE (&quot;AGREEMENT&quot;). ANY USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT&apos;S ACCEPTANCE OF THIS AGREEMENT.&#xA;&#xA;1. DEFINITIONS&#xA;&#xA;&quot;Contribution&quot; means:&#xA;&#xA;a) in the case of the initial Contributor, the initial code and documentation distributed under this Agreement, and&#xA;b) in the case of each subsequent Contributor:&#xA;i) changes to the Program, and&#xA;ii) additions to the Program;&#xA;where such changes and/or additions to the Program originate from and are distributed by that particular Contributor. A Contribution &apos;originates&apos; from a Contributor if it was added to the Program by such Contributor itself or anyone acting on such Contributor&apos;s behalf. Contributions do not include additions to the Program which: (i) are separate modules of software distributed in conjunction with the Program under their own license agreement, and (ii) are not derivative works of the Program.&#xA;&quot;Contributor&quot; means any person or entity that distributes the Program.&#xA;&#xA;&quot;Licensed Patents&quot; mean patent claims licensable by a Contributor which are necessarily infringed by the use or sale of its Contribution alone or when combined with the Program.&#xA;&#xA;&quot;Program&quot; means the Contributions distributed in accordance with this Agreement.&#xA;&#xA;&quot;Recipient&quot; means anyone who receives the Program under this Agreement, including all Contributors.&#xA;&#xA;2. GRANT OF RIGHTS&#xA;&#xA;a) Subject to the terms of this Agreement, each Contributor hereby grants Recipient a non-exclusive, worldwide, royalty-free copyright license to reproduce, prepare derivative works of, publicly display, publicly perform, distribute and sublicense the Contribution of such Contributor, if any, and such derivative works, in source code and object code form.&#xA;b) Subject to the terms of this Agreement, each Contributor hereby grants Recipient a non-exclusive, worldwide, royalty-free patent license under Licensed Patents to make, use, sell, offer to sell, import and otherwise transfer the Contribution of such Contributor, if any, in source code and object code form. This patent license shall apply to the combination of the Contribution and the Program if, at the time the Contribution is added by the Contributor, such addition of the Contribution causes such combination to be covered by the Licensed Patents. The patent license shall not apply to any other combinations which include the Contribution. No hardware per se is licensed hereunder.&#xA;c) Recipient understands that although each Contributor grants the licenses to its Contributions set forth herein, no assurances are provided by any Contributor that the Program does not infringe the patent or other intellectual property rights of any other entity. Each Contributor disclaims any liability to Recipient for claims brought by any other entity based on infringement of intellectual property rights or otherwise. As a condition to exercising the rights and licenses granted hereunder, each Recipient hereby assumes sole responsibility to secure any other intellectual property rights needed, if any. For example, if a third party patent license is required to allow Recipient to distribute the Program, it is Recipient&apos;s responsibility to acquire that license before distributing the Program.&#xA;d) Each Contributor represents that to its knowledge it has sufficient copyright rights in its Contribution, if any, to grant the copyright license set forth in this Agreement.&#xA;3. REQUIREMENTS&#xA;&#xA;A Contributor may choose to distribute the Program in object code form under its own license agreement, provided that:&#xA;&#xA;a) it complies with the terms and conditions of this Agreement; and&#xA;b) its license agreement:&#xA;i) effectively disclaims on behalf of all Contributors all warranties and conditions, express and implied, including warranties or conditions of title and non-infringement, and implied warranties or conditions of merchantability and fitness for a particular purpose;&#xA;ii) effectively excludes on behalf of all Contributors all liability for damages, including direct, indirect, special, incidental and consequential damages, such as lost profits;&#xA;iii) states that any provisions which differ from this Agreement are offered by that Contributor alone and not by any other party; and&#xA;iv) states that source code for the Program is available from such Contributor, and informs licensees how to obtain it in a reasonable manner on or through a medium customarily used for software exchange.&#xA;When the Program is made available in source code form:&#xA;&#xA;a) it must be made available under this Agreement; and&#xA;b) a copy of this Agreement must be included with each copy of the Program.&#xA;Contributors may not remove or alter any copyright notices contained within the Program.&#xA;&#xA;Each Contributor must identify itself as the originator of its Contribution, if any, in a manner that reasonably allows subsequent Recipients to identify the originator of the Contribution.&#xA;&#xA;4. COMMERCIAL DISTRIBUTION&#xA;&#xA;Commercial distributors of software may accept certain responsibilities with respect to end users, business partners and the like. While this license is intended to facilitate the commercial use of the Program, the Contributor who includes the Program in a commercial product offering should do so in a manner which does not create potential liability for other Contributors. Therefore, if a Contributor includes the Program in a commercial product offering, such Contributor (&quot;Commercial Contributor&quot;) hereby agrees to defend and indemnify every other Contributor (&quot;Indemnified Contributor&quot;) against any losses, damages and costs (collectively &quot;Losses&quot;) arising from claims, lawsuits and other legal actions brought by a third party against the Indemnified Contributor to the extent caused by the acts or omissions of such Commercial Contributor in connection with its distribution of the Program in a commercial product offering. The obligations in this section do not apply to any claims or Losses relating to any actual or alleged intellectual property infringement. In order to qualify, an Indemnified Contributor must: a) promptly notify the Commercial Contributor in writing of such claim, and b) allow the Commercial Contributor to control, and cooperate with the Commercial Contributor in, the defense and any related settlement negotiations. The Indemnified Contributor may participate in any such claim at its own expense.&#xA;&#xA;For example, a Contributor might include the Program in a commercial product offering, Product X. That Contributor is then a Commercial Contributor. If that Commercial Contributor then makes performance claims, or offers warranties related to Product X, those performance claims and warranties are such Commercial Contributor&apos;s responsibility alone. Under this section, the Commercial Contributor would have to defend claims against the other Contributors related to those performance claims and warranties, and if a court requires any other Contributor to pay any damages as a result, the Commercial Contributor must pay those damages.&#xA;&#xA;5. NO WARRANTY&#xA;&#xA;EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, THE PROGRAM IS PROVIDED ON AN &quot;AS IS&quot; BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. Each Recipient is solely responsible for determining the appropriateness of using and distributing the Program and assumes all risks associated with its exercise of rights under this Agreement , including but not limited to the risks and costs of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and unavailability or interruption of operations.&#xA;&#xA;6. DISCLAIMER OF LIABILITY&#xA;&#xA;EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, NEITHER RECIPIENT NOR ANY CONTRIBUTORS SHALL HAVE ANY LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING WITHOUT LIMITATION LOST PROFITS), HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OR DISTRIBUTION OF THE PROGRAM OR THE EXERCISE OF ANY RIGHTS GRANTED HEREUNDER, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.&#xA;&#xA;7. GENERAL&#xA;&#xA;If any provision of this Agreement is invalid or unenforceable under applicable law, it shall not affect the validity or enforceability of the remainder of the terms of this Agreement, and without further action by the parties hereto, such provision shall be reformed to the minimum extent necessary to make such provision valid and enforceable.&#xA;&#xA;If Recipient institutes patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Program itself (excluding combinations of the Program with other software or hardware) infringes such Recipient&apos;s patent(s), then such Recipient&apos;s rights granted under Section 2(b) shall terminate as of the date such litigation is filed.&#xA;&#xA;All Recipient&apos;s rights under this Agreement shall terminate if it fails to comply with any of the material terms or conditions of this Agreement and does not cure such failure in a reasonable period of time after becoming aware of such noncompliance. If all Recipient&apos;s rights under this Agreement terminate, Recipient agrees to cease use and distribution of the Program as soon as reasonably practicable. However, Recipient&apos;s obligations under this Agreement and any licenses granted by Recipient relating to the Program shall continue and survive.&#xA;&#xA;Everyone is permitted to copy and distribute copies of this Agreement, but in order to avoid inconsistency the Agreement is copyrighted and may only be modified in the following manner. The Agreement Steward reserves the right to publish new versions (including revisions) of this Agreement from time to time. No one other than the Agreement Steward has the right to modify this Agreement. The Eclipse Foundation is the initial Agreement Steward. The Eclipse Foundation may assign the responsibility to serve as the Agreement Steward to a suitable separate entity. Each new version of the Agreement will be given a distinguishing version number. The Program (including Contributions) may always be distributed subject to the version of the Agreement under which it was received. In addition, after a new version of the Agreement is published, Contributor may elect to distribute the Program (including its Contributions) under the new version. Except as expressly stated in Sections 2(a) and 2(b) above, Recipient receives no rights or licenses to the intellectual property of any Contributor under this Agreement, whether expressly, by implication, estoppel or otherwise. All rights in the Program not expressly granted under this Agreement are reserved.&#xA;&#xA;This Agreement is governed by the laws of the State of New York and the intellectual property laws of the United States of America. No party to this Agreement will bring a legal action under this Agreement more than one year after the cause of action arose. Each party waives its rights to a jury trial in any resulting litigation.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2024 Broadcom'/>
        <property name='df_LT.description' value='This feature contains the Eclipse-UI-specific STS 4 components'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.main.feature.feature.group' version='4.23.1.202406150140'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.xml.bind' range='[2.2.0,2.3.0)' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.main.feature_root' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.validation' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.sun.xml.bind' range='[2.3.0,2.4.0)' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.wizard' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.imports' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.launch' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.main.feature.feature.jar' range='[4.23.1.202406150140,4.23.1.202406150140]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.maven.pom' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.buildship30' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.xml.namespaces.feature.feature.group' range='3.9.9'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.restart' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseUrl' url='%25licenseUrl'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.springframework.boot.ide.main.feature_root' version='4.23.1.202406150140'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.springframework.boot.ide.main.feature_root' version='4.23.1.202406150140'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.springframework.boot.ide.main.feature_root' version='4.23.1.202406150140'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.springframework.ide.eclipse.boot.dash.feature.feature.group' version='4.23.1.202406150140' singleton='false'>
      <update id='org.springframework.ide.eclipse.boot.dash.feature.feature.group' range='[0.0.0,4.23.1.202406150140)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.springframework.ide.eclipse'/>
        <property name='maven-artifactId' value='org.springframework.ide.eclipse.boot.dash.feature'/>
        <property name='maven-version' value='4.23.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='SPRING IDE PROJECT SOFTWARE USER AGREEMENT&#xA;March 26, 2007&#xA;&#xA;Usage Of Content&#xA;&#xA;THE SPRING IDE PROJECT MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Spring IDE Project is provided to you under the terms and conditions of the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also available at https://www.eclipse.org/legal/epl-v10.html. For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation and other files maintained in the springsource.org SVN repository (&quot;Repository&quot;) in CVS modules (&quot;Modules&quot;) and made available as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering, extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java? ARchive) in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material. Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;Features may also include other Features (&quot;Included Features&quot;). Files named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features and Included Features should be contained in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any directory of a Download or Module including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Spring IDE project is installed using the Eclipse Update Manager, you must agree to a license (&quot;Feature Update License&quot;) during the installation process. If the Feature contains Included Features, the Feature Update License should either provide you with the terms and conditions governing the Included Features or inform you where you can locate them. Feature Update Licenses may be found in the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature. Such Abouts, Feature Licenses, and Feature Update Licenses contain the terms and conditions (or references to such terms and conditions) that govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Public License Version 1.0 (available at https://www.eclipse.org/legal/epl-v10.html)&#xA;- Eclipse Distribution License Version 1.0 (available at https://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at https://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at https://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at https://www.apache.org/licenses/LICENSE-2.0)&#xA;- Mozilla Public License Version 1.1 (available at https://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License is provided, please contact the Spring IDE project to determine what terms and conditions govern that particular Content.&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently may have restrictions on the import, possession, and use, and/or re-export to another country, of encryption software. BEFORE using any encryption software, please check the country&amp;apos;s laws, regulations and policies concerning the import, possession, or use, and re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Sun Microsystems, Inc. in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2005, 2012 Spring IDE Developers&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;Spring IDE Developers - initial API and implementation'/>
        <property name='df_LT.featureName' value='Spring IDE Boot Microservices Dash'/>
        <property name='df_LT.description' value='This feature provides a View for working with Spring Boot Microservices'/>
        <property name='df_LT.providerName' value='Spring IDE Developers'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.dash.feature.feature.group' version='4.23.1.202406150140'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.dash' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.dash.docker' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.refactoring' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.editor.support' range='[4.23.1.202406141939,4.23.1.202406141939]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.beans.ui.live' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.docker.client' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='io.projectreactor.reactor-core' range='[3.3.1.202211021051-RELEASE,3.3.1.202211021051-RELEASE]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.reactivestreams.reactive-streams' range='[1.0.3,1.0.3]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springsource.ide.eclipse.commons.jdk_tools' range='[4.23.1.202406141939,4.23.1.202406141939]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.boot.dash.feature.feature.jar' range='[4.23.1.202406150140,4.23.1.202406150140]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseUrl' url='%25licenseUrl'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.springframework.ide.eclipse.xml.namespaces.feature.feature.group' version='4.23.1.202406150140' singleton='false'>
      <update id='org.springframework.ide.eclipse.xml.namespaces.feature.feature.group' range='[0.0.0,4.23.1.202406150140)' severity='0'/>
      <properties size='13'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.springframework.ide.eclipse'/>
        <property name='maven-artifactId' value='org.springframework.ide.eclipse.xml.namespaces.feature'/>
        <property name='maven-version' value='4.23.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='SPRING IDE PROJECT SOFTWARE USER AGREEMENT&#xA;March 26, 2007&#xA;&#xA;Usage Of Content&#xA;&#xA;THE SPRING IDE PROJECT MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Spring IDE Project is provided to you under the terms and conditions of the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also available at https://www.eclipse.org/legal/epl-v10.html. For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation and other files maintained in the springsource.org SVN repository (&quot;Repository&quot;) in CVS modules (&quot;Modules&quot;) and made available as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering, extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java? ARchive) in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material. Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;Features may also include other Features (&quot;Included Features&quot;). Files named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features and Included Features should be contained in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any directory of a Download or Module including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Spring IDE project is installed using the Eclipse Update Manager, you must agree to a license (&quot;Feature Update License&quot;) during the installation process. If the Feature contains Included Features, the Feature Update License should either provide you with the terms and conditions governing the Included Features or inform you where you can locate them. Feature Update Licenses may be found in the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature. Such Abouts, Feature Licenses, and Feature Update Licenses contain the terms and conditions (or references to such terms and conditions) that govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Public License Version 1.0 (available at https://www.eclipse.org/legal/epl-v10.html)&#xA;- Eclipse Distribution License Version 1.0 (available at https://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at https://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at https://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at https://www.apache.org/licenses/LICENSE-2.0)&#xA;- Mozilla Public License Version 1.1 (available at https://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License is provided, please contact the Spring IDE project to determine what terms and conditions govern that particular Content.&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently may have restrictions on the import, possession, and use, and/or re-export to another country, of encryption software. BEFORE using any encryption software, please check the country&amp;apos;s laws, regulations and policies concerning the import, possession, or use, and re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Sun Microsystems, Inc. in the United States, other countries, or both.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2005, 2012 Spring IDE Developers&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;https://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;Spring IDE Developers - initial API and implementation'/>
        <property name='df_LT.featureName' value='Spring XML Namespace Support'/>
        <property name='df_LT.description' value='This feature provides tool support for The Spring Framework.'/>
        <property name='df_LT.providerName' value='Broadcom'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.xml.namespaces.feature.feature.group' version='4.23.1.202406150140'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.xml.namespaces' range='[4.23.1.202406150140,4.23.1.202406150140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.ide.eclipse.xml.namespaces.feature.feature.jar' range='[4.23.1.202406150140,4.23.1.202406150140]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseUrl' url='%25licenseUrl'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.springframework.tooling.boot.ls.feature.feature.group' version='4.23.1.202406141939' singleton='false' generation='2'>
      <update id='org.springframework.tooling.boot.ls.feature.feature.group' range='[0.0.0,4.23.1.202406141939)' severity='0'/>
      <properties size='11'>
        <property name='org.eclipse.equinox.p2.name' value='Spring Boot Language Server Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Broadcom'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='maven-groupId' value='org.springframework.boot.ide'/>
        <property name='maven-artifactId' value='org.springframework.tooling.boot.ls.feature'/>
        <property name='maven-version' value='4.23.1-SNAPSHOT'/>
        <property name='maven-type' value='eclipse-feature'/>
        <property name='df_LT.license' value='The content of this package is provided under the EPL v1.0 license (see below).&#xA;For a detailed overview of embedded third-party components and their OSS licenses, please take a look at the detailed license information in the bundle itself: META-INF/third-party-open-source-licenses.txt (for an overview of used open-source components) and META-INF/third-party-open-source-licenses/ (detailed used open-source licenses)&#xA;&#xA;===&#xA;&#xA;Eclipse Public License - v 1.0&#xA;&#xA;THE ACCOMPANYING PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE PUBLIC LICENSE (&quot;AGREEMENT&quot;). ANY USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM CONSTITUTES RECIPIENT&apos;S ACCEPTANCE OF THIS AGREEMENT.&#xA;&#xA;1. DEFINITIONS&#xA;&#xA;&quot;Contribution&quot; means:&#xA;&#xA;a) in the case of the initial Contributor, the initial code and documentation distributed under this Agreement, and&#xA;b) in the case of each subsequent Contributor:&#xA;i) changes to the Program, and&#xA;ii) additions to the Program;&#xA;where such changes and/or additions to the Program originate from and are distributed by that particular Contributor. A Contribution &apos;originates&apos; from a Contributor if it was added to the Program by such Contributor itself or anyone acting on such Contributor&apos;s behalf. Contributions do not include additions to the Program which: (i) are separate modules of software distributed in conjunction with the Program under their own license agreement, and (ii) are not derivative works of the Program.&#xA;&quot;Contributor&quot; means any person or entity that distributes the Program.&#xA;&#xA;&quot;Licensed Patents&quot; mean patent claims licensable by a Contributor which are necessarily infringed by the use or sale of its Contribution alone or when combined with the Program.&#xA;&#xA;&quot;Program&quot; means the Contributions distributed in accordance with this Agreement.&#xA;&#xA;&quot;Recipient&quot; means anyone who receives the Program under this Agreement, including all Contributors.&#xA;&#xA;2. GRANT OF RIGHTS&#xA;&#xA;a) Subject to the terms of this Agreement, each Contributor hereby grants Recipient a non-exclusive, worldwide, royalty-free copyright license to reproduce, prepare derivative works of, publicly display, publicly perform, distribute and sublicense the Contribution of such Contributor, if any, and such derivative works, in source code and object code form.&#xA;b) Subject to the terms of this Agreement, each Contributor hereby grants Recipient a non-exclusive, worldwide, royalty-free patent license under Licensed Patents to make, use, sell, offer to sell, import and otherwise transfer the Contribution of such Contributor, if any, in source code and object code form. This patent license shall apply to the combination of the Contribution and the Program if, at the time the Contribution is added by the Contributor, such addition of the Contribution causes such combination to be covered by the Licensed Patents. The patent license shall not apply to any other combinations which include the Contribution. No hardware per se is licensed hereunder.&#xA;c) Recipient understands that although each Contributor grants the licenses to its Contributions set forth herein, no assurances are provided by any Contributor that the Program does not infringe the patent or other intellectual property rights of any other entity. Each Contributor disclaims any liability to Recipient for claims brought by any other entity based on infringement of intellectual property rights or otherwise. As a condition to exercising the rights and licenses granted hereunder, each Recipient hereby assumes sole responsibility to secure any other intellectual property rights needed, if any. For example, if a third party patent license is required to allow Recipient to distribute the Program, it is Recipient&apos;s responsibility to acquire that license before distributing the Program.&#xA;d) Each Contributor represents that to its knowledge it has sufficient copyright rights in its Contribution, if any, to grant the copyright license set forth in this Agreement.&#xA;3. REQUIREMENTS&#xA;&#xA;A Contributor may choose to distribute the Program in object code form under its own license agreement, provided that:&#xA;&#xA;a) it complies with the terms and conditions of this Agreement; and&#xA;b) its license agreement:&#xA;i) effectively disclaims on behalf of all Contributors all warranties and conditions, express and implied, including warranties or conditions of title and non-infringement, and implied warranties or conditions of merchantability and fitness for a particular purpose;&#xA;ii) effectively excludes on behalf of all Contributors all liability for damages, including direct, indirect, special, incidental and consequential damages, such as lost profits;&#xA;iii) states that any provisions which differ from this Agreement are offered by that Contributor alone and not by any other party; and&#xA;iv) states that source code for the Program is available from such Contributor, and informs licensees how to obtain it in a reasonable manner on or through a medium customarily used for software exchange.&#xA;When the Program is made available in source code form:&#xA;&#xA;a) it must be made available under this Agreement; and&#xA;b) a copy of this Agreement must be included with each copy of the Program.&#xA;Contributors may not remove or alter any copyright notices contained within the Program.&#xA;&#xA;Each Contributor must identify itself as the originator of its Contribution, if any, in a manner that reasonably allows subsequent Recipients to identify the originator of the Contribution.&#xA;&#xA;4. COMMERCIAL DISTRIBUTION&#xA;&#xA;Commercial distributors of software may accept certain responsibilities with respect to end users, business partners and the like. While this license is intended to facilitate the commercial use of the Program, the Contributor who includes the Program in a commercial product offering should do so in a manner which does not create potential liability for other Contributors. Therefore, if a Contributor includes the Program in a commercial product offering, such Contributor (&quot;Commercial Contributor&quot;) hereby agrees to defend and indemnify every other Contributor (&quot;Indemnified Contributor&quot;) against any losses, damages and costs (collectively &quot;Losses&quot;) arising from claims, lawsuits and other legal actions brought by a third party against the Indemnified Contributor to the extent caused by the acts or omissions of such Commercial Contributor in connection with its distribution of the Program in a commercial product offering. The obligations in this section do not apply to any claims or Losses relating to any actual or alleged intellectual property infringement. In order to qualify, an Indemnified Contributor must: a) promptly notify the Commercial Contributor in writing of such claim, and b) allow the Commercial Contributor to control, and cooperate with the Commercial Contributor in, the defense and any related settlement negotiations. The Indemnified Contributor may participate in any such claim at its own expense.&#xA;&#xA;For example, a Contributor might include the Program in a commercial product offering, Product X. That Contributor is then a Commercial Contributor. If that Commercial Contributor then makes performance claims, or offers warranties related to Product X, those performance claims and warranties are such Commercial Contributor&apos;s responsibility alone. Under this section, the Commercial Contributor would have to defend claims against the other Contributors related to those performance claims and warranties, and if a court requires any other Contributor to pay any damages as a result, the Commercial Contributor must pay those damages.&#xA;&#xA;5. NO WARRANTY&#xA;&#xA;EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, THE PROGRAM IS PROVIDED ON AN &quot;AS IS&quot; BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. Each Recipient is solely responsible for determining the appropriateness of using and distributing the Program and assumes all risks associated with its exercise of rights under this Agreement , including but not limited to the risks and costs of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and unavailability or interruption of operations.&#xA;&#xA;6. DISCLAIMER OF LIABILITY&#xA;&#xA;EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, NEITHER RECIPIENT NOR ANY CONTRIBUTORS SHALL HAVE ANY LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING WITHOUT LIMITATION LOST PROFITS), HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OR DISTRIBUTION OF THE PROGRAM OR THE EXERCISE OF ANY RIGHTS GRANTED HEREUNDER, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.&#xA;&#xA;7. GENERAL&#xA;&#xA;If any provision of this Agreement is invalid or unenforceable under applicable law, it shall not affect the validity or enforceability of the remainder of the terms of this Agreement, and without further action by the parties hereto, such provision shall be reformed to the minimum extent necessary to make such provision valid and enforceable.&#xA;&#xA;If Recipient institutes patent litigation against any entity (including a cross-claim or counterclaim in a lawsuit) alleging that the Program itself (excluding combinations of the Program with other software or hardware) infringes such Recipient&apos;s patent(s), then such Recipient&apos;s rights granted under Section 2(b) shall terminate as of the date such litigation is filed.&#xA;&#xA;All Recipient&apos;s rights under this Agreement shall terminate if it fails to comply with any of the material terms or conditions of this Agreement and does not cure such failure in a reasonable period of time after becoming aware of such noncompliance. If all Recipient&apos;s rights under this Agreement terminate, Recipient agrees to cease use and distribution of the Program as soon as reasonably practicable. However, Recipient&apos;s obligations under this Agreement and any licenses granted by Recipient relating to the Program shall continue and survive.&#xA;&#xA;Everyone is permitted to copy and distribute copies of this Agreement, but in order to avoid inconsistency the Agreement is copyrighted and may only be modified in the following manner. The Agreement Steward reserves the right to publish new versions (including revisions) of this Agreement from time to time. No one other than the Agreement Steward has the right to modify this Agreement. The Eclipse Foundation is the initial Agreement Steward. The Eclipse Foundation may assign the responsibility to serve as the Agreement Steward to a suitable separate entity. Each new version of the Agreement will be given a distinguishing version number. The Program (including Contributions) may always be distributed subject to the version of the Agreement under which it was received. In addition, after a new version of the Agreement is published, Contributor may elect to distribute the Program (including its Contributions) under the new version. Except as expressly stated in Sections 2(a) and 2(b) above, Recipient receives no rights or licenses to the intellectual property of any Contributor under this Agreement, whether expressly, by implication, estoppel or otherwise. All rights in the Program not expressly granted under this Agreement are reserved.&#xA;&#xA;This Agreement is governed by the laws of the State of New York and the intellectual property laws of the United States of America. No party to this Agreement will bring a legal action under this Agreement more than one year after the cause of action arose. Each party waives its rights to a jury trial in any resulting litigation.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2024 Broadcom'/>
        <property name='df_LT.description' value='Spring Boot Language Server'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.springframework.tooling.boot.ls.feature.feature.group' version='4.23.1.202406141939'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required match='providedCapabilities.exists(x | x.name == $0 &amp;&amp; x.namespace == $1)' matchParameters='[&apos;org.springframework.tooling.boot.java.ls.feature.feature.group&apos;, &apos;org.eclipse.equinox.p2.iu&apos;]' min='0' max='0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.tooling.ls.eclipse.gotosymbol' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.tooling.boot.ls' range='[1.55.1.202406141939,1.55.1.202406141939]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.springframework.tooling.boot.ls.feature.feature.jar' range='[4.23.1.202406141939,4.23.1.202406141939]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required match='providedCapabilities.exists(x | x.name == $0 &amp;&amp; x.namespace == $1)' matchParameters='[&apos;org.springframework.tooling.properties.ls.feature.feature.group&apos;, &apos;org.eclipse.equinox.p2.iu&apos;]' min='0' max='0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.lsp4e' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.genericeditor' range='0.0.0'>
          <filter>
            (!(org.eclipse.equinox.p2.exclude.import=true))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseUrl' url='%25licenseUrl'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
  </units>
  <iusProperties size='40'>
    <iuProperties id='SharedProfile_DefaultProfile' version='1.0.0.1761728855841'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='com.chabicht.code_intelligence.feature.feature.group' version='1.0.0.202506262339'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.buildship.feature.group' version='3.1.9.v20240115-1636'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.egit.feature.group' version='6.10.0.202406032230-r'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.egit.gitflow.feature.feature.group' version='6.10.0.202406032230-r'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.epp.mpc.feature.group' version='1.10.3.v20240228-1000'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.equinox.p2.user.ui.feature.group' version='2.4.2400.v20240519-2013'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.help.feature.group' version='2.3.1800.v20240601-0610'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jdt.bcoview.feature.feature.group' version='1.2.400.v20240322-0935'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jdt.feature.group' version='3.19.500.v20240601-0610'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jgit.feature.group' version='6.10.0.202406032230-r'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jgit.lfs.feature.group' version='6.10.0.202406032230-r'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jst.server_adapters.ext.feature.feature.group' version='3.4.1000.v202405180431'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jst.server_adapters.feature.feature.group' version='3.34.0.v202405180407'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.justj.openjdk.hotspot.jre.full.feature.group' version='21.0.3.v20240426-1530'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.linuxtools.docker.feature.feature.group' version='5.15.0.202406032109'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.linuxtools.jdt.docker.launcher.feature.feature.group' version='5.15.0.202406032109'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.feature.feature.group' version='2.6.1.20240602-2342'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.lemminx.feature.feature.group' version='2.0.600.20240219-1707'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.logback.feature.feature.group' version='2.6.1.20240411-1743'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.m2e.wtp.feature.feature.group' version='1.6.1.20231024-1618'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.mylyn.wikitext.feature.feature.group' version='4.3.0.v20240602-0603'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.pde.feature.group' version='3.15.400.v20240601-0610'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='4.32.0.v20240601-0610'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE' value='/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE/.eclipseproduct|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='4.32.0.v20240601-0610'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE' value='/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE/readme|/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE/readme/readme_eclipse.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.tips.feature.feature.group' version='0.4.400.v20240525-0701'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.tm.terminal.feature.feature.group' version='11.6.0.202403071917'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.wildwebdeveloper.feature.feature.group' version='1.3.6.202405280856'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.wildwebdeveloper.xml.feature.feature.group' version='1.3.4.202405270639'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.wst.server_adapters.feature.feature.group' version='3.34.0.v202405181536'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.wst.server_ui.feature.feature.group' version='3.3.1900.v202405150145'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.jboss.tools.m2e.wro4j.feature.feature.group' version='1.2.1.202301111328'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.sonatype.m2e.egit.feature.feature.group' version='0.17.0.202209271423'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.springframework.boot.ide.branding.sts4' version='4.23.1.202406150140'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.springframework.boot.ide.branding.sts4.executable.win32.win32.x86_64' version='4.23.1.202406150140'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE' value='/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE/SpringToolSuite4.exe|/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE/SpringToolSuite4c.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.springframework.boot.ide.main.feature.feature.group' version='4.23.1.202406150140'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.springframework.boot.ide.main.feature_root' version='4.23.1.202406150140'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE' value='/home/runner/work/sts4/sts4/eclipse-distribution/org.springframework.boot.ide.product.e432/target/products/org.springframework.boot.ide.branding.sts4/win32/win32/x86_64/sts-4.23.1.RELEASE/license.txt|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.springframework.ide.eclipse.boot.dash.feature.feature.group' version='4.23.1.202406150140'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.springframework.ide.eclipse.xml.namespaces.feature.feature.group' version='4.23.1.202406150140'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.springframework.tooling.boot.ls.feature.feature.group' version='4.23.1.202406141939'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
